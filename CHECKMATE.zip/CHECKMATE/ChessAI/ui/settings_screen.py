"""
settings_screen.py
-------------------
Persistent app settings stored in the platform-safe Kivy user_data_dir.
The screen keeps the same settings promised by the project documentation:
AI difficulty, default color, sound, legal-move highlighting, and theme.
"""

import json
import os

from kivy.app import App
from kivy.metrics import dp
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDIconButton, MDRaisedButton, MDFlatButton
from kivymd.uix.label import MDLabel
from kivymd.uix.dialog import MDDialog
from kivymd.uix.list import MDList, TwoLineRightIconListItem, IRightBodyTouch
from kivymd.uix.selectioncontrol import MDSwitch
from kivy.uix.scrollview import ScrollView


DEFAULT_SETTINGS = {
    "ai_difficulty": "medium",
    "default_color": "white",
    "sound_on": True,
    "highlight_legal_moves": True,
    "theme": "dark",
}


class RightSwitch(IRightBodyTouch, MDSwitch):
    pass


def _settings_path():
    """Return the Android/desktop-safe settings path."""
    app = App.get_running_app()
    base = app.user_data_dir if app is not None else os.path.join(os.getcwd(), "data")
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, "settings.json")


def load_settings():
    """Load settings and merge them over defaults so older files remain valid."""
    settings = DEFAULT_SETTINGS.copy()
    try:
        with open(_settings_path(), "r", encoding="utf-8") as handle:
            saved = json.load(handle)
        if isinstance(saved, dict):
            settings.update({key: value for key, value in saved.items() if key in DEFAULT_SETTINGS})
    except (OSError, ValueError, TypeError):
        pass
    return settings


def save_settings(settings):
    """Persist only known settings; failures are intentionally non-fatal."""
    safe = DEFAULT_SETTINGS.copy()
    if isinstance(settings, dict):
        safe.update({key: value for key, value in settings.items() if key in DEFAULT_SETTINGS})
    try:
        with open(_settings_path(), "w", encoding="utf-8") as handle:
            json.dump(safe, handle, indent=2)
    except OSError:
        pass


class SettingsScreen(MDScreen):
    def __init__(self, **kwargs):
        # ScreenManager registers this screen as "settings" in main.py.
        # Do not override self.name here; doing so breaks navigation.
        super().__init__(**kwargs)
        self.settings = load_settings()
        self._switches = {}
        self._choice_dialog = None

        layout = MDBoxLayout(
            orientation="vertical",
            md_bg_color=(0.031, 0.039, 0.059, 1),
            padding=[dp(18), dp(12), dp(18), dp(18)],
            spacing=dp(8),
        )

        top_bar = MDBoxLayout(size_hint_y=None, height=dp(52), spacing=dp(6))
        back_btn = MDIconButton(icon="arrow-left", on_release=self.go_back)
        top_bar.add_widget(back_btn)
        top_bar.add_widget(MDLabel(
            text="Settings",
            font_style="H5",
            bold=True,
            theme_text_color="Custom",
            text_color=(0.957, 0.965, 0.980, 1),
            valign="center",
        ))
        layout.add_widget(top_bar)

        scroll = ScrollView()
        self.settings_list = MDList()
        scroll.add_widget(self.settings_list)
        layout.add_widget(scroll)

        self._build_settings()

        reset_btn = MDRaisedButton(
            text="RESET TO DEFAULTS",
            size_hint=(1, None),
            height=dp(46),
            on_release=self.reset_defaults,
            md_bg_color=(0.122, 0.149, 0.200, 1),
            theme_text_color="Custom",
            text_color=(0.957, 0.965, 0.980, 1),
            elevation=0,
        )
        layout.add_widget(reset_btn)
        self.add_widget(layout)

    def _build_settings(self):
        self.settings_list.clear_widgets()
        self._switches.clear()

        self._add_switch(
            "Sound Effects",
            "Enable or disable game sounds",
            "sound_on",
        )
        self._add_switch(
            "Legal Move Hints",
            "Highlight legal destination squares",
            "highlight_legal_moves",
        )
        self._add_choice(
            "Default AI Difficulty",
            "Choose the difficulty used when opening Play vs AI",
            "ai_difficulty",
            [("Easy", "easy"), ("Medium", "medium"), ("Hard", "hard")],
        )
        self._add_choice(
            "Default Player Color",
            "Choose your starting color for Play vs AI",
            "default_color",
            [("White", "white"), ("Black", "black")],
        )
        self._add_choice(
            "Theme",
            "Choose the app appearance",
            "theme",
            [("Dark", "dark"), ("Light", "light")],
        )

    def _add_switch(self, title, subtitle, key):
        item = TwoLineRightIconListItem(text=title, secondary_text=subtitle)
        switch = RightSwitch(active=bool(self.settings[key]))
        switch.bind(active=lambda _switch, value, setting_key=key: self._set_bool(setting_key, value))
        item.add_widget(switch)
        self._switches[key] = switch
        self.settings_list.add_widget(item)

    def _add_choice(self, title, subtitle, key, choices):
        item = MDBoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp(64),
            padding=[dp(16), dp(6), dp(8), dp(6)],
            spacing=dp(8),
        )
        labels = MDBoxLayout(orientation="vertical")
        labels.add_widget(MDLabel(
            text=title,
            theme_text_color="Custom",
            text_color=(0.957, 0.965, 0.980, 1),
            valign="bottom",
        ))
        labels.add_widget(MDLabel(
            text=subtitle,
            theme_text_color="Custom",
            text_color=(0.580, 0.639, 0.722, 1),
            font_style="Caption",
            valign="top",
        ))
        item.add_widget(labels)
        current = str(self.settings[key]).capitalize()
        button = MDFlatButton(
            text=current,
            theme_text_color="Custom",
            text_color=(0.0, 0.898, 1.0, 1),
            size_hint_x=None,
            width=dp(92),
        )
        button.bind(on_release=lambda *_args, k=key, c=choices: self._open_choice(k, c))
        item.add_widget(button)
        self.settings_list.add_widget(item)

    def _open_choice(self, key, choices):
        content = MDBoxLayout(
            orientation="vertical",
            spacing=dp(8),
            size_hint_y=None,
            height=dp(56 * len(choices)),
            padding=dp(4),
        )
        for label, value in choices:
            button = MDRaisedButton(
                text=label,
                size_hint=(1, None),
                height=dp(44),
                md_bg_color=(0.122, 0.149, 0.200, 1),
                theme_text_color="Custom",
                text_color=(0.957, 0.965, 0.980, 1),
                elevation=0,
            )
            button.bind(on_release=lambda *_args, k=key, v=value: self._set_choice(k, v))
            content.add_widget(button)

        self._choice_dialog = MDDialog(
            title="Choose setting",
            type="custom",
            content_cls=content,
            buttons=[MDFlatButton(text="CANCEL", on_release=lambda *_: self._dismiss_choice())],
        )
        self._choice_dialog.open()

    def _dismiss_choice(self):
        if self._choice_dialog:
            self._choice_dialog.dismiss()
            self._choice_dialog = None

    def _set_choice(self, key, value):
        self.settings[key] = value
        save_settings(self.settings)
        if key == "theme":
            app = App.get_running_app()
            if app is not None:
                app.theme_cls.theme_style = "Dark" if value == "dark" else "Light"
        self._dismiss_choice()
        self._build_settings()

    def _set_bool(self, key, value):
        self.settings[key] = bool(value)
        save_settings(self.settings)

    def reset_defaults(self, _instance):
        self.settings = DEFAULT_SETTINGS.copy()
        save_settings(self.settings)
        self._build_settings()

    def on_pre_enter(self, *args):
        # Reload in case another screen changed the saved preferences.
        self.settings = load_settings()
        self._build_settings()

    def go_back(self, _instance):
        # main.py registers HomeScreen with the name "home".
        self.manager.current = "home"
