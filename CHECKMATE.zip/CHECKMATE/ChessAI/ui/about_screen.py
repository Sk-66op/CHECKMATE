"""
about_screen.py
----------------
Simple informational screen for the project (name, purpose, tech
stack) -- useful to show during the viva as a quick project summary.
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivy.metrics import dp


class AboutScreen(MDScreen):
    def __init__(self, **kwargs):
        # ScreenManager registers this screen as "about" in main.py.
        # Do not override self.name here; doing so breaks navigation.
        super().__init__(**kwargs)

        layout = MDBoxLayout(
            orientation="vertical",
            padding=dp(24),
            spacing=dp(16),
            pos_hint={"center_x": 0.5, "center_y": 0.5},
            adaptive_height=True,
        )

        top_bar = MDBoxLayout(size_hint_y=None, height=dp(48))
        top_bar.add_widget(MDIconButton(icon="arrow-left", on_release=self.go_back))
        top_bar.add_widget(MDLabel(
            text="About",
            font_style="H5",
            bold=True,
            theme_text_color="Primary",
            valign="center",
        ))

        title = MDLabel(
            text="ChessAI Checkmate",
            halign="center",
            theme_text_color="Primary",
            font_style="H4",
        )

        description = MDLabel(
            text=(
                "A 2nd-year B.Tech mini-project featuring a custom chess engine.\n\n"
                "Built with Python, Kivy/KivyMD, python-chess, Minimax and Alpha-Beta pruning."
            ),
            halign="center",
            theme_text_color="Secondary",
        )

        back_btn = MDRaisedButton(
            text="BACK TO HOME",
            pos_hint={"center_x": 0.5},
            on_release=self.go_back,
        )

        layout.add_widget(top_bar)
        layout.add_widget(title)
        layout.add_widget(description)
        layout.add_widget(back_btn)
        self.add_widget(layout)

    def go_back(self, _instance):
        # main.py registers HomeScreen with the name "home".
        self.manager.current = "home"
