"""
chess_board_widget.py
----------------------
The interactive 8x8 board. Pure Kivy widget, drawn entirely on the
Canvas so it scales cleanly to any Android screen size (no fixed
pixel assets required to lay out the grid itself).

PUBLIC INTERFACE (unchanged from the previous version -- GameScreen
depends on all of this):
    ChessBoardWidget(Widget)
        .on_square_tapped          # callback(square_name), set externally
        .flipped                   # bool, set externally
        .set_board_state(piece_positions, selected_square=None,
                          legal_targets=None, last_move=None,
                          check_square=None)
        .square_size()
        .on_touch_down(touch)      # standard Kivy touch handler

PIECES:
Unicode chess glyphs (kept -- no new image assets, keeps the APK
light per the brief), rendered in layers per square:
  1. a soft dark drop-shadow, offset down-right
  2. a thin outline in every direction (this is what makes a piece
     readable regardless of which square color it lands on -- pure
     color-tinting alone was not enough contrast against the new
     dark board)
  3. the glyph itself, tinted ivory for white pieces / a lighter
     slate for black pieces (pure black would vanish into the dark
     squares)
  4. for white pieces only, a subtle top-left highlight for a soft
     glossy look
"""

from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle, Ellipse, Line
from kivy.core.text import Label as CoreLabel

FILES = "abcdefgh"

UNICODE_PIECES = {
    ("K", True): "\u2654", ("Q", True): "\u2655", ("R", True): "\u2656",
    ("B", True): "\u2657", ("N", True): "\u2658", ("P", True): "\u2659",
    ("K", False): "\u265A", ("Q", False): "\u265B", ("R", False): "\u265C",
    ("B", False): "\u265D", ("N", False): "\u265E", ("P", False): "\u265F",
}

# ---- design system (matches the rest of the app) ----
LIGHT_SQUARE = (0.137, 0.165, 0.220, 1)   # subtle slate, not a "light" square
DARK_SQUARE = (0.086, 0.106, 0.149, 1)    # near-background
BOARD_BORDER = (0.30, 0.85, 1.0, 0.35)    # faint accent frame

SELECTED_RING = (0.0, 0.90, 1.0, 0.9)
SELECTED_FILL = (0.0, 0.90, 1.0, 0.12)
LAST_MOVE_COLOR = (0.0, 0.90, 1.0, 0.14)
CHECK_COLOR = (1.0, 0.30, 0.42, 0.55)
LEGAL_DOT_COLOR = (0.0, 0.90, 1.0, 0.85)
LEGAL_RING_COLOR = (1.0, 0.30, 0.42, 0.75)

WHITE_PIECE_COLOR = (0.96, 0.97, 0.98, 1)     # near --text
BLACK_PIECE_COLOR = (0.42, 0.47, 0.55, 1)     # lighter than pure black so
                                                # it still reads on the dark
                                                # square, tinted toward
                                                # --text2
OUTLINE_FOR_WHITE = (0, 0, 0, 0.55)
OUTLINE_FOR_BLACK = (0.75, 0.85, 0.92, 0.35)   # faint cool rim so black
                                                # pieces don't merge into
                                                # dark squares


class ChessBoardWidget(Widget):
    """Renders the board + pieces and reports taps back to the game
    screen via `on_square_tapped(square_name)`. Does not know chess
    rules itself -- it just displays whatever state it's given."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.piece_positions = {}       # {square_name: (symbol, is_white)}
        self.selected_square = None
        self.legal_targets = []         # list of square names
        self.last_move = None           # (from_sq, to_sq) or None
        self.check_square = None        # square name of king in check, or None
        self.on_square_tapped = None    # callback set by game_screen
        self.flipped = False            # True to show Black at bottom

        self._glyph_cache = {}

        self.bind(pos=self._redraw, size=self._redraw)

    # ------------------------------------------------------------------
    def set_board_state(self, piece_positions, selected_square=None,
                         legal_targets=None, last_move=None, check_square=None):
        self.piece_positions = piece_positions
        self.selected_square = selected_square
        self.legal_targets = legal_targets or []
        self.last_move = last_move
        self.check_square = check_square
        self._redraw()

    def square_size(self):
        return min(self.width, self.height) / 8.0

    def _square_to_screen(self, square_name):
        """Convert 'e4' style square name to the bottom-left pixel
        coordinate of that square on screen, respecting board flip."""
        file_idx = FILES.index(square_name[0])
        rank_idx = int(square_name[1]) - 1

        if self.flipped:
            file_idx = 7 - file_idx
            rank_idx = 7 - rank_idx

        size = self.square_size()
        x = self.x + file_idx * size
        y = self.y + rank_idx * size
        return x, y

    def _screen_to_square(self, x, y):
        size = self.square_size()
        file_idx = int((x - self.x) // size)
        rank_idx = int((y - self.y) // size)
        if not (0 <= file_idx <= 7 and 0 <= rank_idx <= 7):
            return None
        if self.flipped:
            file_idx = 7 - file_idx
            rank_idx = 7 - rank_idx
        return f"{FILES[file_idx]}{rank_idx + 1}"

    # ------------------------------------------------------------------
    def on_touch_down(self, touch):
        if not self.collide_point(*touch.pos):
            return False
        square = self._screen_to_square(*touch.pos)
        if square and self.on_square_tapped:
            self.on_square_tapped(square)
        return True

    # ------------------------------------------------------------------
    def _redraw(self, *args):
        self.canvas.clear()
        size = self.square_size()
        board_px = size * 8

        with self.canvas:
            # Squares
            for file_idx in range(8):
                for rank_idx in range(8):
                    is_light = (file_idx + rank_idx) % 2 == 1
                    Color(*(LIGHT_SQUARE if is_light else DARK_SQUARE))
                    sx = self.x + file_idx * size
                    sy = self.y + rank_idx * size
                    Rectangle(pos=(sx, sy), size=(size, size))

            # Last-move highlight (subtle accent wash, drawn first so
            # everything else layers cleanly on top of it)
            if self.last_move:
                for sq in self.last_move:
                    self._draw_fill(sq, LAST_MOVE_COLOR, size)

            # Check highlight -- strong but clean, a filled square
            if self.check_square:
                self._draw_fill(self.check_square, CHECK_COLOR, size)

            # Selected square -- accent ring + faint fill, elegant
            # rather than a flat color block
            if self.selected_square:
                self._draw_fill(self.selected_square, SELECTED_FILL, size)
                self._draw_ring(self.selected_square, SELECTED_RING, size, inset=2)

            # Legal moves -- small dot for a quiet move, hollow ring
            # near the edge for a capture
            for sq in self.legal_targets:
                self._draw_legal_marker(sq, size)

            # Pieces (with pseudo-3D shadow/outline/highlight layering)
            for square_name, (symbol, is_white) in self.piece_positions.items():
                self._draw_piece_glyph(square_name, symbol, is_white, size)

            # Board frame -- faint accent border ties the board to the
            # rest of the design system instead of floating unbordered
            Color(*BOARD_BORDER)
            Line(rectangle=(self.x, self.y, board_px, board_px), width=1.2)

    # ------------------------------------------------------------------
    def _draw_fill(self, square_name, color, size):
        x, y = self._square_to_screen(square_name)
        Color(*color)
        Rectangle(pos=(x, y), size=(size, size))

    def _draw_ring(self, square_name, color, size, inset=2):
        x, y = self._square_to_screen(square_name)
        Color(*color)
        Line(rectangle=(x + inset, y + inset, size - inset * 2, size - inset * 2),
             width=max(1.2, size * 0.025))

    def _draw_legal_marker(self, square_name, size):
        x, y = self._square_to_screen(square_name)
        cx, cy = x + size / 2, y + size / 2
        is_capture = square_name in self.piece_positions

        if is_capture:
            Color(*LEGAL_RING_COLOR)
            radius = size * 0.42
            Line(circle=(cx, cy, radius), width=max(1.4, size * 0.035))
        else:
            Color(*LEGAL_DOT_COLOR)
            radius = size * 0.13
            Ellipse(pos=(cx - radius, cy - radius), size=(radius * 2, radius * 2))

    # ------------------------------------------------------------------
    def _draw_piece_glyph(self, square_name, symbol, is_white, size):
        x, y = self._square_to_screen(square_name)
        glyph = UNICODE_PIECES[(symbol, is_white)]
        font_size = int(size * 0.72)

        texture = self._glyph_texture(glyph, font_size)
        tex_w, tex_h = texture.size
        draw_x = x + (size - tex_w) / 2
        draw_y = y + (size - tex_h) / 2
        offset = max(1, size * 0.02)
        outline = max(1, size * 0.035)

        # 1. Shadow layer (down-right, dark, semi-transparent)
        Color(0, 0, 0, 0.35)
        Rectangle(texture=texture, pos=(draw_x + offset, draw_y - offset), size=(tex_w, tex_h))

        # 2. Outline in four directions so the glyph keeps a crisp
        # silhouette against either square color
        Color(*(OUTLINE_FOR_WHITE if is_white else OUTLINE_FOR_BLACK))
        for ox, oy in ((outline, 0), (-outline, 0), (0, outline), (0, -outline)):
            Rectangle(texture=texture, pos=(draw_x + ox, draw_y + oy), size=(tex_w, tex_h))

        # 3. Base glyph, tinted by actual piece color
        Color(*(WHITE_PIECE_COLOR if is_white else BLACK_PIECE_COLOR))
        Rectangle(texture=texture, pos=(draw_x, draw_y), size=(tex_w, tex_h))

        # 4. Highlight layer (up-left, bright, subtle) -- glossy
        # top-light, mainly visible on white pieces.
        if is_white:
            Color(1, 1, 1, 0.30)
            Rectangle(texture=texture, pos=(draw_x - offset * 0.6, draw_y + offset * 0.6),
                       size=(tex_w, tex_h))

    def _glyph_texture(self, glyph, font_size):
        """Cache rendered glyph textures per (glyph, font_size) so we
        don't re-rasterize text every single frame redraw."""
        key = (glyph, font_size)
        if key not in self._glyph_cache:
            label = CoreLabel(text=glyph, font_size=font_size)
            label.refresh()
            self._glyph_cache[key] = label.texture
        return self._glyph_cache[key]
