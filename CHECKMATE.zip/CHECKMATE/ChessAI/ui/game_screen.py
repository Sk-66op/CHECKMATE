"""
game_screen.py
---------------
The main gameplay screen -- "Compact HUD" layout (Option B):
opponent info folds into a slim top bar so the board gets maximum
space, controls sit in a small icon dock under the board, and a
slim "you" status row sits at the very bottom.

INTERFACE PRESERVED EXACTLY as before -- this file still only does
UI wiring, all chess logic still goes through MoveManager:
    start_new_game(mode, human_is_white, ai_difficulty)
    _on_square_tapped, _show_promotion_dialog, _complete_promotion
    _refresh_board, _move_to_square_name, _captured_text, _history_text
    _on_ai_thinking_start, _on_ai_thinking_end, _on_game_over
    _on_undo, _on_restart, _on_resign, _on_menu, _show_dialog

WHAT CHANGED FROM THE BRIEF'S WISH LIST, AND WHY:
  - HINT: MoveManager has no hint-generation method anywhere in the
    engine. Rather than fake a hint, the Hint control is rendered
    disabled (dimmed, non-interactive) with a short note on tap
    explaining it isn't implemented yet. Wire it up once/if
    MoveManager grows a real hint method.
  - Move history moves from an always-visible scrolling strip into a
    "Moves" dialog you open on demand -- same data
    (_history_text/san_history), just presented as a proper
    numbered list instead of one long scrolling line.
  - Game-over now shows a proper result dialog with PLAY AGAIN (reuses
    the last mode/color/difficulty) and HOME, instead of a plain OK
    box. The result text itself is untouched -- still whatever
    MoveManager.on_game_over passes in.
"""

from kivy.uix.screenmanager import Screen
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.behaviors import ButtonBehavior
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.label import MDLabel
from kivymd.uix.dialog import MDDialog

from ui.widgets.chess_board_widget import ChessBoardWidget
from chess_engine.move_manager import MoveManager

# ---- design system ----
BG = (0.031, 0.039, 0.059, 1)
SURFACE = (0.082, 0.098, 0.137, 1)
ELEVATED = (0.122, 0.149, 0.200, 1)
ACCENT = (0.0, 0.898, 1.0, 1)
TEXT = (0.957, 0.965, 0.980, 1)
TEXT2 = (0.580, 0.639, 0.722, 1)
MUTED = (0.392, 0.455, 0.545, 1)
DANGER = (1.0, 0.298, 0.416, 1)


class _IconTile(ButtonBehavior, MDBoxLayout):
    """Small rounded, tappable square used for the control dock --
    plain Kivy canvas rounded-rect background, no extra dependency
    or reliance on a specific icon-font name."""

    def __init__(self, glyph, label_text, danger=False, disabled_look=False, **kwargs):
        super().__init__(orientation="vertical", spacing=dp(2), **kwargs)
        self.size_hint = (None, None)
        self.size = (dp(52), dp(52))
        color = DANGER if danger else TEXT
        if disabled_look:
            color = MUTED
        self._bg_color = ELEVATED if not disabled_look else (0.09, 0.11, 0.15, 1)

        with self.canvas.before:
            Color(*self._bg_color)
            self._rect = RoundedRectangle(radius=[dp(12)], pos=self.pos, size=self.size)
        self.bind(pos=self._sync_rect, size=self._sync_rect)

        icon_lbl = MDLabel(text=glyph, halign="center", theme_text_color="Custom",
                            text_color=color, font_size=dp(18), size_hint_y=None, height=dp(24))
        text_lbl = MDLabel(text=label_text, halign="center", font_style="Caption",
                            theme_text_color="Custom", text_color=color if not disabled_look else MUTED,
                            size_hint_y=None, height=dp(12))
        self.add_widget(icon_lbl)
        self.add_widget(text_lbl)

    def _sync_rect(self, *args):
        self._rect.pos = self.pos
        self._rect.size = self.size


class GameScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.move_manager = None
        self.pending_mode = "pvp"
        self.dialog = None
        self._pending_promotion = None
        self._last_mode = "pvp"
        self._last_human_is_white = True
        self._last_ai_difficulty = "medium"

        root = MDBoxLayout(orientation="vertical", md_bg_color=BG)

        # --- Top HUD bar: opponent info + menu ---
        hud = MDBoxLayout(size_hint_y=None, height=dp(56), padding=[dp(14), dp(8)],
                           spacing=dp(10), md_bg_color=SURFACE)
        avatar = MDLabel(text="\u265E", halign="center", theme_text_color="Custom",
                          text_color=ACCENT, size_hint=(None, None), size=(dp(30), dp(30)))
        hud.add_widget(avatar)
        opp_col = MDBoxLayout(orientation="vertical")
        self.opp_title = MDLabel(text="CHESS AI", font_style="Caption", bold=True,
                                  theme_text_color="Custom", text_color=TEXT,
                                  size_hint_y=None, height=dp(16))
        self.opp_status = MDLabel(text="", font_style="Caption",
                                   theme_text_color="Custom", text_color=TEXT2,
                                   size_hint_y=None, height=dp(14))
        opp_col.add_widget(self.opp_title)
        opp_col.add_widget(self.opp_status)
        hud.add_widget(opp_col)
        hud.add_widget(MDBoxLayout())  # spacer
        menu_btn = MDFlatButton(text="Menu", theme_text_color="Custom", text_color=TEXT2)
        menu_btn.bind(on_release=lambda *_: self._on_menu())
        hud.add_widget(menu_btn)
        root.add_widget(hud)

        # --- Board (gets the remaining space) ---
        board_container = MDBoxLayout(padding=dp(14))
        self.board_widget = ChessBoardWidget(size_hint=(1, 1))
        self.board_widget.on_square_tapped = self._on_square_tapped
        board_container.add_widget(self.board_widget)
        root.add_widget(board_container)

        # --- Captured pieces (compact caption under the board) ---
        self.captured_label = MDLabel(text="", halign="center", font_style="Caption",
                                       size_hint_y=None, height=dp(20),
                                       theme_text_color="Custom", text_color=MUTED)
        root.add_widget(self.captured_label)

        # --- Control dock ---
        dock_wrap = MDBoxLayout(size_hint_y=None, height=dp(72), padding=[dp(14), dp(8)])
        dock = MDBoxLayout(spacing=dp(14), pos_hint={"center_x": 0.5}, size_hint_x=None)
        dock.width = dp(52) * 4 + dp(14) * 3

        undo_tile = _IconTile("\u21ba", "Undo")
        undo_tile.bind(on_release=lambda *_: self._on_undo())
        dock.add_widget(undo_tile)

        hint_tile = _IconTile("\U0001F4A1", "Hint", disabled_look=True)
        hint_tile.bind(on_release=lambda *_: self._show_hint_unavailable())
        dock.add_widget(hint_tile)

        moves_tile = _IconTile("\u2630", "Moves")
        moves_tile.bind(on_release=lambda *_: self._show_move_history())
        dock.add_widget(moves_tile)

        resign_tile = _IconTile("\u2691", "Resign", danger=True)
        resign_tile.bind(on_release=lambda *_: self._on_resign())
        dock.add_widget(resign_tile)

        dock_wrap.add_widget(dock)
        root.add_widget(dock_wrap)

        # --- "You" status row ---
        you_row = MDBoxLayout(size_hint_y=None, height=dp(30), padding=[dp(16), 0],
                               md_bg_color=SURFACE)
        self.you_label = MDLabel(text="YOU", font_style="Caption", bold=True,
                                  theme_text_color="Custom", text_color=TEXT)
        self.status_label = MDLabel(text="White to move", halign="right", font_style="Caption",
                                     theme_text_color="Custom", text_color=TEXT2)
        you_row.add_widget(self.you_label)
        you_row.add_widget(self.status_label)
        root.add_widget(you_row)

        self.add_widget(root)

        # Kept for compatibility with anything that expects a
        # history_label attribute to exist; no longer shown inline
        # (see the "Moves" dialog instead).
        self.history_label = MDLabel(text="")

        # Board-tap selection state
        self.selected_square = None

    # ------------------------------------------------------------------
    def _update_history_height(self, *args):
        # No longer used (history moved to a dialog) -- kept as a
        # no-op so nothing breaks if anything still calls it.
        pass

    # ------------------------------------------------------------------
    def start_new_game(self, mode="pvp", human_is_white=True, ai_difficulty="medium"):
        if self.move_manager is not None:
            self.move_manager.close()
        self._pending_promotion = None
        self._last_mode = mode
        self._last_human_is_white = human_is_white
        self._last_ai_difficulty = ai_difficulty

        self.move_manager = MoveManager(mode=mode, human_is_white=human_is_white,
                                         ai_difficulty=ai_difficulty)
        self.move_manager.on_ai_move_start = self._on_ai_thinking_start
        self.move_manager.on_ai_move_end = self._on_ai_thinking_end
        self.move_manager.on_game_over = self._on_game_over
        self.board_widget.flipped = (mode == "pva" and not human_is_white)
        self.selected_square = None

        self.opp_title.text = "CHESS AI" if mode == "pva" else "OPPONENT"
        self.opp_status.text = ai_difficulty.upper() if mode == "pva" else "Local player"
        self.you_label.text = "YOU"

        self._refresh_board()
        # If the human chose Black, the AI must play White's first
        # move now -- otherwise the game would silently sit waiting
        # for a human turn that isn't coming.
        self.move_manager.maybe_start_ai_turn()

    # ------------------------------------------------------------------
    def _on_square_tapped(self, square):
        if self.move_manager is None or self.move_manager.ai_thinking:
            return
        if not self.move_manager.is_human_turn():
            return
        if self.move_manager.is_game_over():
            return

        bm = self.move_manager.board_manager

        if self.selected_square is None:
            # First tap: select a piece if it belongs to the side to move.
            piece_map = bm.piece_map()
            if square in piece_map:
                _, is_white = piece_map[square]
                if is_white == bm.turn_is_white():
                    self.selected_square = square
                    self._refresh_board()
            return

        if square == self.selected_square:
            self.selected_square = None
            self._refresh_board()
            return

        # Second tap: promotion needs a piece choice before the move is pushed.
        if bm.is_promotion(self.selected_square, square):
            self._pending_promotion = (self.selected_square, square)
            self._show_promotion_dialog()
            return

        moved = self.move_manager.attempt_human_move(self.selected_square, square)
        self.selected_square = None
        if not moved:
            # Maybe they tapped a different one of their own pieces instead.
            piece_map = bm.piece_map()
            if square in piece_map and piece_map[square][1] == bm.turn_is_white():
                self.selected_square = square
        self._refresh_board()

    # ------------------------------------------------------------------
    def _show_promotion_dialog(self):
        options = MDBoxLayout(orientation="vertical", spacing=dp(8),
                               size_hint_y=None, height=dp(220), padding=dp(8))
        for label, code in [("Queen", "q"), ("Rook", "r"), ("Bishop", "b"), ("Knight", "n")]:
            btn = MDRaisedButton(text=label, size_hint_y=None, height=dp(44),
                                  size_hint_x=1, md_bg_color=ELEVATED,
                                  theme_text_color="Custom", text_color=TEXT, elevation=0)
            btn.bind(on_release=lambda *_a, c=code: self._complete_promotion(c))
            options.add_widget(btn)
        self.dialog = MDDialog(title="Choose promotion", type="custom",
                                content_cls=options, md_bg_color=SURFACE)
        self.dialog.open()

    def _complete_promotion(self, promotion):
        if self.dialog:
            self.dialog.dismiss()
        pending = self._pending_promotion
        self._pending_promotion = None
        if not pending or self.move_manager is None:
            return
        from_sq, to_sq = pending
        moved = self.move_manager.attempt_human_move(from_sq, to_sq, promotion)
        self.selected_square = None
        if not moved:
            self.selected_square = from_sq
        self._refresh_board()

    # ------------------------------------------------------------------
    def _refresh_board(self):
        bm = self.move_manager.board_manager
        legal_targets = []
        if self.selected_square:
            legal_targets = [self._move_to_square_name(m) for m in
                              bm.legal_moves_from(self.selected_square)]

        self.board_widget.set_board_state(
            piece_positions=bm.piece_map(),
            selected_square=self.selected_square,
            legal_targets=legal_targets,
            last_move=bm.last_move_squares(),
            check_square=bm.king_square_in_check(),
        )

        turn_text = "White" if bm.turn_is_white() else "Black"
        status = f"{turn_text} to move"
        if bm.is_check():
            status += "  \u2022  CHECK"
        self.status_label.text = status

        self.captured_label.text = self._captured_text(bm)
        self.history_label.text = self._history_text(bm)

    def _move_to_square_name(self, move):
        import chess
        return chess.square_name(move.to_square)

    def _captured_text(self, bm):
        w = " ".join(bm.captured_white) or "-"
        b = " ".join(bm.captured_black) or "-"
        return f"White captured: {w}    Black captured: {b}"

    def _history_text(self, bm):
        pairs = []
        moves = bm.san_history
        for i in range(0, len(moves), 2):
            num = i // 2 + 1
            white_move = moves[i]
            black_move = moves[i + 1] if i + 1 < len(moves) else ""
            pairs.append(f"{num}. {white_move}    {black_move}")
        return "\n".join(pairs) if pairs else "No moves yet."

    # ------------------------------------------------------------------
    def _show_move_history(self):
        """'Moves' dock button -- reads the same san_history data the
        old scrolling label used, just shown as a scrollable numbered
        list in a dialog instead of one long inline strip."""
        if self.move_manager is None:
            return
        bm = self.move_manager.board_manager
        body = MDLabel(text=self._history_text(bm), theme_text_color="Custom",
                        text_color=TEXT, size_hint_y=None)
        body.bind(texture_size=lambda inst, val: setattr(inst, "height", val[1]))
        self.dialog = MDDialog(title="Move history", type="custom", content_cls=body,
                                md_bg_color=SURFACE)
        self.dialog.open()

    def _show_hint_unavailable(self):
        self._show_dialog("Hint", "Hint isn't implemented in this version of the engine yet.")

    # ------------------------------------------------------------------
    def _on_ai_thinking_start(self):
        self.opp_status.text = (self._last_ai_difficulty.upper() + " \u2022 thinking\u2026"
                                 if self._last_mode == "pva" else self.opp_status.text)
        self.status_label.text = "AI is thinking..."

    def _on_ai_thinking_end(self, move):
        if self._last_mode == "pva":
            self.opp_status.text = self._last_ai_difficulty.upper()
        self._refresh_board()

    def _on_game_over(self, result_text):
        self._show_game_over_dialog(result_text)

    # ------------------------------------------------------------------
    def _on_undo(self):
        if self.move_manager and self.move_manager.undo():
            self.selected_square = None
            self._refresh_board()

    def _on_restart(self):
        if self.move_manager:
            self.move_manager.restart()
            self.selected_square = None
            self._refresh_board()

    def _on_resign(self):
        if self.move_manager:
            self.move_manager.resign()

    def _on_menu(self):
        self.manager.current = "home"

    # ------------------------------------------------------------------
    def _show_dialog(self, title, text):
        if self.dialog:
            self.dialog.dismiss()
        self.dialog = MDDialog(title=title, text=text, md_bg_color=SURFACE,
                                buttons=[MDFlatButton(text="OK", theme_text_color="Custom",
                                         text_color=ACCENT,
                                         on_release=lambda *_: self.dialog.dismiss())])
        self.dialog.open()

    def _show_game_over_dialog(self, result_text):
        """Premium result state: PLAY AGAIN restarts with the exact
        same mode/color/difficulty as the game that just ended; HOME
        returns to the landing screen. Result logic itself (what
        result_text says) is untouched -- this only changes how it's
        presented."""
        if self.dialog:
            self.dialog.dismiss()

        def _play_again(*_):
            self.dialog.dismiss()
            self.start_new_game(mode=self._last_mode,
                                 human_is_white=self._last_human_is_white,
                                 ai_difficulty=self._last_ai_difficulty)

        def _go_home(*_):
            self.dialog.dismiss()
            self.manager.current = "home"

        self.dialog = MDDialog(
            title="Game Over",
            text=result_text,
            md_bg_color=SURFACE,
            buttons=[
                MDFlatButton(text="HOME", theme_text_color="Custom", text_color=TEXT2,
                             on_release=_go_home),
                MDRaisedButton(text="PLAY AGAIN", md_bg_color=ACCENT, theme_text_color="Custom",
                               text_color=(0.02, 0.14, 0.16, 1), on_release=_play_again),
            ],
        )
        self.dialog.open()
