[app]

title = CHECKMATE
package.name = checkmate
package.domain = org.miniproject.checkmate

source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,atlas,json,ttf,wav,ogg,mp3

version = 1.0

requirements = python3,kivy==2.1.0,kivymd==1.1.1,chess==1.10.0,pillow

orientation = portrait
fullscreen = 0

# Force specific versions
android.permissions = INTERNET
android.api = 30
android.minapi = 21
android.ndk = 23b
android.build_tools = 30.0.3
android.archs = arm64-v8a, armeabi-v7a
android.allow_backup = True
android.enable_androidx = True

# Don't let Buildozer auto-detect
android.sdk_path = 
android.ndk_path = 
android.ant_path =

[buildozer]
log_level = 2
warn_on_root = 1
