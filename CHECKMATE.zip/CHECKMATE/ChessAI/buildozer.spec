[app]

title = CHECKMATE
package.name = checkmate
package.domain = org.miniproject.checkmate

source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,atlas,json,ttf,wav,ogg,mp3

version = 1.0

requirements = python3,kivy==2.2.1,kivymd==1.1.1,chess==1.10.0,pillow

orientation = portrait
fullscreen = 0

# Use API 30 instead of 33 (more stable)
android.permissions = INTERNET
android.api = 30
android.minapi = 21
android.ndk = 23b
android.archs = arm64-v8a, armeabi-v7a
android.allow_backup = True

# Enable AndroidX
android.enable_androidx = True

[buildozer]
log_level = 2
warn_on_root = 1
