[app]

# ---------------------------------------------------------
# Application identity
# ---------------------------------------------------------

title = CHECKMATE
package.name = checkmate
package.domain = org.miniproject

version = 1.0


# ---------------------------------------------------------
# Source
# ---------------------------------------------------------

source.dir = .

source.include_exts = py,png,jpg,jpeg,kv,atlas,json,ttf,wav,ogg,mp3

source.exclude_dirs = .venv,.git,__pycache__,build,bin,.github


# ---------------------------------------------------------
# Dependencies
# ---------------------------------------------------------

requirements = python3,kivy==2.1.0,kivymd==1.1.1,chess==1.10.0,pillow


# ---------------------------------------------------------
# Application settings
# ---------------------------------------------------------

orientation = portrait
fullscreen = 0


# ---------------------------------------------------------
# Android
# ---------------------------------------------------------

android.permissions = INTERNET

android.api = 31
android.minapi = 21

android.ndk = 23b

android.archs = arm64-v8a


# ---------------------------------------------------------
# Android application options
# ---------------------------------------------------------

android.allow_backup = True
android.enable_androidx = True


# ---------------------------------------------------------
# Buildozer
# ---------------------------------------------------------

[buildozer]

log_level = 2
warn_on_root = 1
