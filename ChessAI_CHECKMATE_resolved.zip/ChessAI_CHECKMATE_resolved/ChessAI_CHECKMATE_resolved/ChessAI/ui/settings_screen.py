"""
settings_screen.py
-------------------
Lets the user configure default AI difficulty, default color,
sound, legal-move highlighting, and theme. Persisted to
data/settings.json under the app's Android-safe user_data_dir.
"""

import json
import os
from kivymd.uix.screen import MDScreen
from kivymd.uix.list import MDList, TwoLineRightIconListItem, IRightBodyTouch
from kivymd.uix.selectioncontrol import MDSwitch
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDIconButton
from kivy.uix.scrollview import ScrollView

class RightSwitch(IRightBodyTouch, MDSwitch):
    pass

class SettingsScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = "settings_screen"
        
        # Main layout
        layout = MDBoxLayout(orientation='vertical')
        
        # Top Bar (Back button)
        top_bar = MDBoxLayout(adaptive_height=True, padding="8dp")
        back_btn = MDIconButton(
            icon="arrow-left",
            on_release=self.go_back
        )
        top_bar.add_widget(back_btn)
        layout.add_widget(top_bar)

        # Scrollable Settings List
        scroll = ScrollView()
        self.settings_list = MDList()
        
        # Add Settings Items
        self.add_setting_toggle("Sound Effects", "Enable or disable game sounds")
        self.add_setting_toggle("Dark Mode", "Toggle application theme")
        
        scroll.add_widget(self.settings_list)
        layout.add_widget(scroll)
        self.add_widget(layout)

    def add_setting_toggle(self, text, secondary_text):
        item = TwoLineRightIconListItem(text=text, secondary_text=secondary_text)
        switch = RightSwitch()
        item.add_widget(switch)
        self.settings_list.add_widget(item)

    def go_back(self, instance):
        self.manager.current = "home_screen"