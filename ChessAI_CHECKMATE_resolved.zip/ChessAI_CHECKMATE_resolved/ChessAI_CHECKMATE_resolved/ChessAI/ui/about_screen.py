"""
about_screen.py
----------------
Simple informational screen for the project (name, purpose, tech
stack) -- useful to show during the viva as a quick project summary.
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton
from kivy.metrics import dp

class AboutScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = "about_screen"
        
        layout = MDBoxLayout(
            orientation="vertical",
            padding=dp(24),
            spacing=dp(16),
            pos_hint={"center_x": 0.5, "center_y": 0.5},
            adaptive_height=True
        )
        
        title = MDLabel(
            text="About ChessAI Checkmate",
            halign="center",
            theme_text_color="Primary",
            font_style="H4"
        )
        
        description = MDLabel(
            text="A 2nd-year B.Tech mini-project featuring a custom chess engine.",
            halign="center",
            theme_text_color="Secondary",
        )
        
        back_btn = MDRaisedButton(
            text="Back to Home",
            pos_hint={"center_x": 0.5},
            on_release=self.go_back
        )
        
        layout.add_widget(title)
        layout.add_widget(description)
        layout.add_widget(back_btn)
        self.add_widget(layout)

    def go_back(self, instance):
        self.manager.current = "home_screen"