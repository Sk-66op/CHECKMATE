"""
home_screen.py
---------------
The app's landing screen -- "Centered Hero" layout (Option A):
mark + app name at top, a glowing king silhouette + "PLAY SMARTER"
in the middle, primary/secondary action buttons, and quiet text
links for Settings / About / Exit at the bottom.

Every public method name from the original file is preserved
(_go_pva, _go_pvp, _go_settings, _go_about, _exit_app and the PvA
picker's _set_pva_color / _set_pva_difficulty / _start_pva) so
nothing elsewhere in the app needs to change.
"""

from kivy.uix.screenmanager import Screen
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.widget import Widget
from kivy.graphics import Color, Ellipse
from kivy.metrics import dp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.label import MDLabel
from kivymd.uix.dialog import MDDialog

# ---- design system ----
BG = (0.031, 0.039, 0.059, 1)          # #080A0F
SURFACE = (0.082, 0.098, 0.137, 1)     # #151923
ELEVATED = (0.122, 0.149, 0.200, 1)    # #1F2633
ACCENT = (0.0, 0.898, 1.0, 1)          # #00E5FF
TEXT = (0.957, 0.965, 0.980, 1)        # #F4F6FA
TEXT2 = (0.580, 0.639, 0.722, 1)       # #94A3B8
MUTED = (0.392, 0.455, 0.545, 1)       # #64748B
DANGER = (1.0, 0.298, 0.416, 1)        # #FF4C6A


class _GlowBackdrop(Widget):
    """Soft radial glow behind the hero king -- a handful of stacked,
    low-alpha circles rather than a real blur (keeps this on plain
    Kivy canvas, no extra dependency)."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.bind(pos=self._redraw, size=self._redraw)

    def _redraw(self, *args):
        self.canvas.clear()
        cx = self.center_x
        cy = self.center_y
        base = min(self.width, self.height)
        with self.canvas:
            for frac, alpha in [(1.0, 0.05), (0.7, 0.08), (0.42, 0.14)]:
                r = base * frac / 2
                Color(ACCENT[0], ACCENT[1], ACCENT[2], alpha)
                Ellipse(pos=(cx - r, cy - r), size=(r * 2, r * 2))


class HomeScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._pva_dialog = None
        self._pva_color = "white"
        self._pva_difficulty = "medium"

        root = MDBoxLayout(orientation="vertical", md_bg_color=BG,
                            padding=[dp(28), dp(36), dp(28), dp(24)], spacing=dp(4))

        # --- Top mark ---
        mark = MDLabel(text="CHESSAI", halign="center", font_style="Overline",
                        theme_text_color="Custom", text_color=MUTED,
                        size_hint_y=None, height=dp(20))
        appname = MDLabel(text="Chess AI Arena", halign="center", font_style="H4",
                           bold=True, theme_text_color="Custom", text_color=TEXT,
                           size_hint_y=None, height=dp(44))
        tagline = MDLabel(text="Play. Think. Improve.", halign="center", font_style="Caption",
                           theme_text_color="Custom", text_color=TEXT2,
                           size_hint_y=None, height=dp(20))
        root.add_widget(mark)
        root.add_widget(appname)
        root.add_widget(tagline)

        # --- Hero: glow + king glyph + "PLAY SMARTER" ---
        hero = FloatLayout(size_hint_y=1)
        glow = _GlowBackdrop(size_hint=(0.85, 0.85), pos_hint={"center_x": 0.5, "center_y": 0.55})
        hero.add_widget(glow)
        king = MDLabel(text="\u2654", halign="center", theme_text_color="Custom",
                        text_color=(ACCENT[0], ACCENT[1], ACCENT[2], 0.22),
                        font_size=dp(120), pos_hint={"center_x": 0.5, "center_y": 0.55},
                        size_hint=(1, 0.7))
        hero.add_widget(king)
        play_smarter = MDLabel(text="PLAY SMARTER", halign="center", font_style="Caption",
                                bold=True, theme_text_color="Custom", text_color=ACCENT,
                                pos_hint={"center_x": 0.5, "y": 0.06}, size_hint=(1, None),
                                height=dp(20))
        hero.add_widget(play_smarter)
        root.add_widget(hero)

        # --- Primary / secondary actions ---
        actions = MDBoxLayout(orientation="vertical", spacing=dp(10),
                               size_hint_y=None, height=dp(120))
        play_ai = MDRaisedButton(text="PLAY VS AI", size_hint=(1, None), height=dp(52),
                                  md_bg_color=ACCENT, theme_text_color="Custom",
                                  text_color=(0.02, 0.14, 0.16, 1), elevation=0,
                                  font_style="Button")
        play_ai.bind(on_release=lambda *_: self._go_pva())
        actions.add_widget(play_ai)

        play_friend = MDRaisedButton(text="PLAY WITH FRIEND", size_hint=(1, None), height=dp(52),
                                      md_bg_color=ELEVATED, theme_text_color="Custom",
                                      text_color=TEXT, elevation=0, font_style="Button")
        play_friend.bind(on_release=lambda *_: self._go_pvp())
        actions.add_widget(play_friend)
        root.add_widget(actions)

        # --- Quiet footer links ---
        footer = MDBoxLayout(size_hint_y=None, height=dp(40), spacing=dp(28),
                              pos_hint={"center_x": 0.5})
        settings_btn = MDFlatButton(text="Settings", theme_text_color="Custom", text_color=TEXT2)
        settings_btn.bind(on_release=lambda *_: self._go_settings())
        about_btn = MDFlatButton(text="About", theme_text_color="Custom", text_color=TEXT2)
        about_btn.bind(on_release=lambda *_: self._go_about())
        exit_btn = MDFlatButton(text="Exit", theme_text_color="Custom", text_color=DANGER)
        exit_btn.bind(on_release=lambda *_: self._exit_app())
        footer.add_widget(settings_btn)
        footer.add_widget(about_btn)
        footer.add_widget(exit_btn)
        root.add_widget(footer)

        self.add_widget(root)

    # ------------------------------------------------------------------
    def _go_pva(self):
        """Show a quick color + difficulty picker before starting a
        Player vs AI game. Same flow/values as before, restyled."""
        content = MDBoxLayout(orientation="vertical", spacing=dp(12),
                               size_hint_y=None, height=dp(170), padding=dp(6))

        color_label = MDLabel(text="Play as", font_style="Caption",
                               theme_text_color="Custom", text_color=TEXT2,
                               size_hint_y=None, height=dp(16))
        content.add_widget(color_label)
        color_row = MDBoxLayout(spacing=dp(8), size_hint_y=None, height=dp(44))
        for label, value in [("White", "white"), ("Black", "black")]:
            b = MDRaisedButton(text=label, md_bg_color=ELEVATED, theme_text_color="Custom",
                                text_color=TEXT, elevation=0)
            b.bind(on_release=lambda *_a, v=value: self._set_pva_color(v))
            color_row.add_widget(b)
        content.add_widget(color_row)

        diff_label = MDLabel(text="Difficulty", font_style="Caption",
                              theme_text_color="Custom", text_color=TEXT2,
                              size_hint_y=None, height=dp(16))
        content.add_widget(diff_label)
        diff_row = MDBoxLayout(spacing=dp(8), size_hint_y=None, height=dp(44))
        for label, value in [("Easy", "easy"), ("Medium", "medium"), ("Hard", "hard")]:
            b = MDRaisedButton(text=label, md_bg_color=ELEVATED, theme_text_color="Custom",
                                text_color=TEXT, elevation=0)
            b.bind(on_release=lambda *_a, v=value: self._set_pva_difficulty(v))
            diff_row.add_widget(b)
        content.add_widget(diff_row)

        self._pva_dialog = MDDialog(
            title="Play vs AI",
            type="custom",
            content_cls=content,
            md_bg_color=SURFACE,
            buttons=[MDRaisedButton(text="Start Game", md_bg_color=ACCENT,
                                     theme_text_color="Custom",
                                     text_color=(0.02, 0.14, 0.16, 1),
                                     on_release=lambda *_: self._start_pva())],
        )
        self._pva_dialog.open()

    def _set_pva_color(self, value):
        self._pva_color = value

    def _set_pva_difficulty(self, value):
        self._pva_difficulty = value

    def _start_pva(self):
        if self._pva_dialog:
            self._pva_dialog.dismiss()
        game_screen = self.manager.get_screen("game")
        game_screen.start_new_game(mode="pva",
                                    human_is_white=(self._pva_color == "white"),
                                    ai_difficulty=self._pva_difficulty)
        self.manager.current = "game"

    def _go_pvp(self):
        game_screen = self.manager.get_screen("game")
        game_screen.start_new_game(mode="pvp")
        self.manager.current = "game"

    def _go_settings(self):
        self.manager.current = "settings"

    def _go_about(self):
        self.manager.current = "about"

    def _exit_app(self):
        from kivy.app import App
        App.get_running_app().stop()
