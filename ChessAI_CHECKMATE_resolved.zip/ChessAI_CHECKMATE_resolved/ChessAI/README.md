# CHECKMATE — Chess AI (Android, Python/Kivy)

A 2nd-year B.Tech mini project: a chess app with Player-vs-AI (Minimax +
Alpha-Beta pruning) and local Player-vs-Player modes, built with
KivyMD and python-chess, packaged for Android via Buildozer.

## Project Structure

```
ChessAI/
├── main.py                        # App entry point / ScreenManager setup
├── ui/
│   ├── home_screen.py             # Landing screen, mode/difficulty picker
│   ├── game_screen.py             # Board + controls + move history
│   ├── settings_screen.py         # Persisted settings (JSON)
│   ├── about_screen.py
│   └── widgets/
│       └── chess_board_widget.py  # 8x8 board, touch input, pseudo-3D pieces
├── chess_engine/
│   ├── board_manager.py           # Wraps python-chess: state, moves, undo
│   ├── ai_engine.py               # Difficulty -> search depth coordinator
│   ├── search.py                  # Minimax + Alpha-Beta recursion
│   ├── evaluation.py              # Position scoring (material, PST, etc.)
│   └── move_manager.py            # Orchestrates PvP/PvA turn flow + threading
├── assets/{pieces,sounds,themes}  # (placeholders — see "Assets" below)
├── data/                          # settings.json is written here at runtime
├── requirements.txt
└── buildozer.spec
```

## 1. Running on Desktop (fastest way to test/iterate)

You need internet access on your own machine for this step (to `pip
install` the dependencies) — this sandbox where the code was written
has no network access, so the packages below were never installed or
run here; the files were hand-written and only syntax-checked
(`python3 -m py_compile`) rather than executed.

```bash
python3 -m venv venv
source venv/bin/activate        # venv\Scripts\activate on Windows
pip install -r requirements.txt
python main.py
```

You should see the home screen. Try:
- **Play vs Player**: tap a piece, tap a destination square.
- **Play vs AI**: pick a color + difficulty, then play. Watch the
  status label show "AI is thinking..." while it searches — the UI
  should stay responsive because the search runs on a background
  thread (see `move_manager.py`).
- **Undo / Restart / Resign / Menu** buttons on the game screen.
- **Settings** screen — change a value, close the app, reopen it; the
  choice should persist (stored in your OS's app data folder as
  `settings.json`).

### Module-by-module testing (recommended order)

1. **`chess_engine/board_manager.py`** — test standalone in a Python
   shell:
   ```python
   from chess_engine.board_manager import BoardManager
   bm = BoardManager()
   bm.make_move("e2", "e4")
   print(bm.board)
   ```
2. **`chess_engine/evaluation.py` + `search.py`** — sanity-check the AI
   without any UI:
   ```python
   import chess
   from chess_engine.search import find_best_move
   board = chess.Board()
   move, score = find_best_move(board, depth=3)
   print(move, score)
   ```
   At depth 3–4 from the starting position you should see a
   reasonable opening move (e.g. a central pawn or knight move), not
   something random like a rook-pawn push.
3. **`chess_engine/ai_engine.py`** — play the AI against itself in a
   loop to confirm it always produces legal moves and the game
   terminates:
   ```python
   import chess
   from chess_engine.ai_engine import AIEngine
   board = chess.Board()
   ai = AIEngine("medium")
   while not board.is_game_over():
       board.push(ai.pick_move(board))
   print(board.result())
   ```
4. Only after 1–3 pass, move on to the UI screens — bugs are far
   easier to isolate in the engine layer than through touch testing.

## 2. Assets ("3D-look" pieces)

No image assets are required to run the app: pieces are drawn with
Unicode chess glyphs (♔♕♖♗♘♙ etc.) directly on the board's Canvas,
layered as **shadow → base glyph → highlight** to fake a glossy/
raised look without real 3D rendering (see the docstring at the top
of `ui/widgets/chess_board_widget.py` for exactly how). This means
the app looks reasonable out of the box and there's nothing to go
missing on Android.

If you later want real piece artwork instead of glyphs, drop PNGs
into `assets/pieces/` (e.g. `wp.png`, `bp.png`, `wk.png`, ...) and
swap `_draw_piece_glyph`'s `CoreLabel`/texture calls for `Image`
loads of those files — keep the same three-layer shadow/highlight
offset trick for a consistent look.

## 3. Building the Android APK

**Buildozer only runs on Linux** (natively; on Windows/macOS use WSL2
or a Linux VM/Docker container). It also needs to download the
Android SDK/NDK (several GB) the first time, so you need a real
internet connection and ~15–45 minutes for the first build.

### One-time setup (on a Linux machine/VM with internet)

```bash
sudo apt update
sudo apt install -y python3-pip build-essential git python3-venv \
    zlib1g-dev libncurses5-dev libffi-dev libssl-dev \
    openjdk-17-jdk unzip

pip3 install --upgrade buildozer cython
```

### Build

From inside the `ChessAI/` project folder (where `buildozer.spec`
lives):

```bash
buildozer android debug
```

This will download/set up the Android SDK + NDK automatically on
first run, then compile the app. The finished APK appears at:

```
bin/chessai-1.0-arm64-v8a_armeabi-v7a-debug.apk
```

Install it on a connected device/emulator with:

```bash
buildozer android deploy run
```

or manually via ADB:

```bash
adb install bin/chessai-1.0-*-debug.apk
```

### If you don't have a Linux machine handy

The easiest path is a free **GitHub Actions** runner (Ubuntu, has
internet, no local setup needed):

1. Push this project to a GitHub repo.
2. Add a workflow (`.github/workflows/build.yml`) that installs the
   same apt packages + buildozer shown above and runs
   `buildozer android debug`.
3. Upload `bin/*.apk` as a workflow artifact and download it from the
   Actions tab.

There are ready-made community actions for this (search
"buildozer github action") if you'd rather not hand-write the YAML.

### Common build issues

- **`Command failed: ... aidl`** — usually a Java/SDK version
  mismatch; stick to `openjdk-17-jdk` and `android.api = 33` as set
  in `buildozer.spec`.
- **KivyMD not found during build** — confirm the `requirements =`
  line in `buildozer.spec` includes `kivymd==1.2.0` exactly (already
  set).
- **App crashes immediately on the phone but works on desktop** —
  check `adb logcat | grep python` for the traceback; the most common
  cause is a file path assumption that doesn't hold on Android (this
  project already uses `App.get_running_app().user_data_dir` for
  settings.json specifically to avoid this).
- **Screen too small / layout cramped** — the board widget sizes
  itself to `min(width, height)`, so it should scale down safely on
  small phones, but test on at least one small-screen emulator
  profile before your demo.

## 4. Known limitations (worth mentioning in your viva)

- Pawn promotion currently auto-promotes to Queen (the vast majority
  case) rather than opening a piece-choice popup — noted directly in
  `game_screen.py` (`_on_square_tapped`) as an easy place to extend.
- Undo in Player-vs-AI mode undoes both the AI's and the human's last
  move (so it's the human's turn again) rather than supporting a full
  move-by-move redo stack.
- The AI is intentionally not "superhuman" — Hard mode searches 4
  ply with alpha-beta pruning and simple move ordering, tuned to stay
  responsive on typical phone hardware, not to play at a professional
  strength.


## Verification status

This version includes the following robustness fixes beyond the original audit:
- Human pawn promotion now presents Queen/Rook/Bishop/Knight choices instead of auto-promoting to a queen.
- Resignation now ends the current game and blocks further moves until Restart/New Game.
- Pending AI results from an abandoned/restarted game are invalidated so a late background calculation cannot modify a new game.
- Kivy is pinned to 2.3.1 with KivyMD 1.2.0; the project continues to use the KivyMD 1.x API already present in the source.

Android packaging still requires an actual Buildozer build on Linux/WSL2. Static checks cannot prove that an APK builds successfully.
