# TEST_REPORT.md — CHECKMATE Code Review & Verification

**Scope of this pass:** review existing code, fix the two reported bugs plus
what they revealed on inspection, verify behavior, no new features.

## Environment constraint (read this first)

This sandbox has **no network access**, so `pip install kivy kivymd chess`
was not possible (verified — `pip install chess` fails with "No matching
distribution found"). That means:

- I could **not** run `python main.py` or exercise the real `python-chess`
  library end-to-end.
- Every file was **syntax-checked** with `python3 -m py_compile` (real,
  executed, all pass).
- The specific bugs fixed below were **verified by extracting the exact
  changed logic into standalone Python** (no Kivy/chess dependency) and
  running it against hand-built test cases and 200 randomized trees for
  the search algorithm. These are real executed tests, not inspection —
  but they test the *logic I changed*, not the full integrated app.
- Chess-rule correctness (legality, castling, en passant, promotion,
  checkmate/stalemate/draw detection) is **delegated entirely to
  python-chess** — `board_manager.py` calls `board.legal_moves`,
  `board.is_checkmate()`, `board.is_stalemate()`, etc. directly and adds
  no rule logic of its own. I reviewed that this delegation is complete
  and unmodified by the wrapper, but I have not executed a real game
  through the real library in this environment. **You should run the
  "Module-by-module testing" steps in README.md yourself on a machine
  with internet access before trusting this in a demo** — I cannot
  claim that verification myself.

## Files reviewed

- `main.py`
- `chess_engine/board_manager.py`
- `chess_engine/evaluation.py`
- `chess_engine/search.py`
- `chess_engine/ai_engine.py`
- `chess_engine/move_manager.py`
- `ui/home_screen.py`
- `ui/game_screen.py`
- `ui/settings_screen.py`
- `ui/about_screen.py`
- `ui/widgets/chess_board_widget.py`
- `buildozer.spec`, `requirements.txt`

## Bugs found and fixed

### 1. AI never played White's opening move when human chose Black
**File:** `chess_engine/move_manager.py`, `ui/game_screen.py`
**Root cause:** `MoveManager` and `start_new_game()` set up state but nothing
ever called `_trigger_ai_move()` at game start — the app only triggered the
AI *in response to* a human move, so if the AI was supposed to move first
there was no event to kick it off. The game would silently sit on the
starting position forever.
**Fix:** added `MoveManager.maybe_start_ai_turn()`, called from
`GameScreen.start_new_game()` right after the board is first drawn. It
checks mode == "pva", game not already over, and it's not the human's turn,
then calls the existing `_trigger_ai_move()` — reusing the same background
thread + `Clock.schedule_once` + `on_ai_move_start`/`on_ai_move_end`
callback path as every other AI move, so "AI is thinking..." displays and
the UI thread is never blocked, same as before.
**Verified:** `/tmp/mock_move_manager_test.py`, Test A — confirms the AI
plays exactly one White move when `human_is_white=False`, and it becomes
the human's turn afterward. (Executed, passed.)

### 2. Undo did not restore captured-piece lists
**File:** `chess_engine/board_manager.py`
**Root cause:** `captured_white`/`captured_black` were appended to on every
capture but never popped in `undo()` — explicitly called out as a shortcut
in the old code's own comment ("captured-piece lists are not rewound for
simplicity"). Undoing a capture left the captured piece still shown as
taken.
**Fix:** added a parallel `_capture_log` stack, one entry per applied move
(`None`, `"white"`, or `"black"`), pushed in `_record_capture()` (now
returns which list it touched instead of mutating blindly) and popped in
`undo()`, removing exactly one entry from the correct list only when that
move actually was a capture. Also cleared in `reset()`.
**Verified:** `/tmp/mock_chess_test.py` — pushes 3 moves (capture, quiet,
capture), asserts `captured_white == ['p','p']`, then undoes all three one
at a time and asserts the list shrinks in exact lock-step
(`['p'] → ['p'] → []`) matching san_history and move_stack length at every
step. (Executed, passed.)

### 3. (Follow-on from #1/#2) Undo in PvA mode used a fixed "pop twice" rule
**File:** `chess_engine/move_manager.py`
**Root cause:** old `undo()` always popped exactly 2 plies in PvA mode
regardless of whose turn it currently was. This breaks in the
human-plays-Black case: if the AI has made only its opening move and the
human hasn't moved yet, popping twice would try to pop from an empty stack
(harmless no-op there) but the *intent* — "undo should return to the
human's turn" — wasn't actually guaranteed for every board state, only the
common one.
**Fix:** changed to a loop that pops one ply at a time and stops as soon as
it's the human's turn again (or the stack is empty), which is correct in
every case: normal human+AI round trip (pops 2), AI-only opening move with
no human move yet (pops 1, correctly can't reach "human's turn" because
there was no human move to undo back to — see caveat below), and PvP (pops
exactly 1, unchanged behavior).
**Verified:** `/tmp/mock_move_manager_test.py`, Tests C, D, E — all pass.
**Remaining caveat:** in test C's exact scenario (undoing the AI's
very-first move before the human has moved at all), the result is the
empty board with it being the AI's turn again, not the human's — because
there is no human move to return to. This is the mathematically correct
behavior, not a bug, but worth knowing: pressing Undo immediately after
choosing "Play Black" will re-trigger the AI to move again once you undo
back to the start (since `is_human_turn()` will again be false) — the UI
does not currently re-call `maybe_start_ai_turn()` after an undo. This is a
minor UX gap, not a crash or rules violation; flagged under Remaining
Limitations rather than fixed, to stay within the requested scope.

## Verification performed

| Area | Method | Result |
|---|---|---|
| Syntax, all 14 `.py` files | `python3 -m py_compile` (executed) | All pass |
| Capture-list undo symmetry | Standalone extracted-logic test, 3 pushes + 3 undos | Pass |
| AI auto-plays as White when human is Black | Standalone extracted-logic test | Pass |
| AI never moves twice / never moves post-game-over | Standalone extracted-logic test | Pass |
| Undo lands on human's turn (PvA round trip, PvP single-ply) | Standalone extracted-logic test | Pass |
| Board tap ↔ square-name mapping, both orientations | Standalone coordinate round-trip test, 128 cases | Pass |
| Board flip renders Black's view correctly (a1↔h8 spot checks) | Standalone coordinate test | Pass |
| Out-of-bounds taps don't crash/misattribute | Standalone coordinate test | Pass |
| Alpha-beta pruning produces the same result as plain minimax | 200 randomized synthetic game trees, depths 2–4, branching 2–4 | Pass, 0 mismatches |
| Legal moves, check, checkmate, stalemate, castling, en passant, promotion, draw conditions | **Not independently executed** — these are handled entirely by `python-chess` internals, which `board_manager.py` calls directly without reimplementing; reviewed the call sites for correctness of *usage* (square parsing, promotion piece mapping, en-passant captured-square math) but the underlying rule engine itself was not run here | Reviewed only |
| Resignation | Reviewed: `resign()` reports the side *not* currently to move as the winner | Reviewed only |
| Android path safety | Reviewed: only `settings_screen.py` touches disk, uses `App.get_running_app().user_data_dir`; no other file does file I/O | Reviewed only |
| No desktop-only dependencies | Reviewed `requirements.txt`/`buildozer.spec`: kivy, kivymd, chess — all pure-Python/cross-platform, no desktop-only libs | Reviewed only |
| `buildozer.spec` completeness | Reviewed: `source.include_exts` covers `.py,.png,.jpg,.jpeg,.kv,.atlas,.json,.ttf,.wav,.ogg,.mp3`; `requirements =` includes `python3,kivy,kivymd,chess,pillow` | Reviewed only |

## Other findings (not fixed — out of scope / not bugs)

- `evaluation.py`'s mobility heuristic temporarily flips `board.turn` to
  count both sides' legal moves, then restores it. This is a common
  toy-engine trick but can slightly mis-count moves tied to en-passant
  availability in rare positions, since en-passant rights are tied to
  whichever side just moved. It never affects actual game legality — it
  only nudges the AI's position scoring — so left as-is per "no
  redesign" instruction; noting it here for awareness.
- `ui/widgets/chess_board_widget.py` imports `Texture` from
  `kivy.graphics.texture` but never uses it directly (textures come from
  `CoreLabel.texture` instead). Harmless unused import, not touched.
- Promotion still auto-queens (already documented as a known limitation
  in README.md from the original build) — unchanged, not in scope.

## Remaining limitations

- Undo immediately after the AI's opening move (human plays Black, no
  human move yet) returns to the AI's turn, not the human's — see bug #3
  caveat above. The AI will re-think and move again once you undo that
  far back, which is correct given there's no human move to land on, but
  may feel surprising in the UI.
- Chess-rule correctness (castling, en passant, promotion, checkmate,
  stalemate, draw detection) has not been executed in this environment —
  it depends on `python-chess`, which could not be installed here. Please
  run the desktop test in README.md ("Running on Desktop") before relying
  on this for a demo.
- KivyMD/Kivy widget behavior (dialogs, switches, scroll view) has not
  been visually verified — no display/runtime available in this sandbox.
