"""
main.py
-------
App entry point. Sets up the ScreenManager with all four screens and
launches the KivyMD app. Run on desktop with:  python main.py
"""

from kivymd.app import MDApp
from kivy.uix.screenmanager import ScreenManager, FadeTransition

from ui.home_screen import HomeScreen
from ui.game_screen import GameScreen
from ui.settings_screen import SettingsScreen
from ui.about_screen import AboutScreen


class ChessAIApp(MDApp):
    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Brown"

        sm = ScreenManager(transition=FadeTransition())
        sm.add_widget(HomeScreen(name="home"))
        sm.add_widget(GameScreen(name="game"))
        sm.add_widget(SettingsScreen(name="settings"))
        sm.add_widget(AboutScreen(name="about"))
        sm.current = "home"
        return sm

    def on_start(self):
        # Handle Android back button gracefully: go to home instead of
        # exiting immediately if we're not already there.
        from kivy.core.window import Window
        Window.bind(on_keyboard=self._on_key)

    def _on_key(self, window, key, *args):
        if key == 27:  # Android/ESC back button
            sm = self.root
            if sm.current != "home":
                sm.current = "home"
                return True
        return False


if __name__ == "__main__":
    ChessAIApp().run()
