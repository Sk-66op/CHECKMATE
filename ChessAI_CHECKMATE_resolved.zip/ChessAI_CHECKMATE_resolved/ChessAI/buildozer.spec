[app]
title = Chess AI
package.name = chessai
package.domain = org.miniproject.checkmate

source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,atlas,json,ttf,wav,ogg,mp3

version = 1.0

# python-chess is pure Python -> pip name is "chess".
# AUDIT: kivy==2.3.0 + kivymd==1.2.0 is not a combination I found
# independently confirmed as a known-working buildozer pairing during
# this audit (see TEST_REPORT / audit notes). If this combination
# fails to build, the most widely documented known-good fallback pin
# is:
#   requirements = python3,kivy==2.2.1,kivymd==1.1.1,sdl2_ttf==2.0.15,chess==1.10.0,pillow
# (sdl2_ttf is pinned there because newer default SDL2_ttf builds have
# caused crashes on some devices in community reports.)
requirements = python3==3.11.9,kivy==2.3.0,kivymd==1.2.0,sdl2_ttf==2.20.1,chess==1.10.0,pillow

orientation = portrait
fullscreen = 0

# Optional: uncomment once you add a 512x512 assets/icon.png
# icon.filename = %(source.dir)s/assets/icon.png

# AUDIT: this app makes no network calls and needs no storage beyond
# its own private app-data settings.json (written via user_data_dir,
# which requires no permission). INTERNET was requested with no
# actual use in the code -- removed. Add permissions back only if a
# feature that needs them is actually added.
android.permissions =
android.api = 33
android.minapi = 21
# AUDIT: 25b is python-for-android's own currently-recommended NDK
# version. If the build fails to compile with it, current Buildozer
# docs (as of mid-2026) confirm 28c also works -- try that as a
# fallback rather than an older version.
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.allow_backup = True

# KivyMD ships as a pure-python recipe via python-for-android's
# "kivymd" garden/recipe support in recent p4a; if the build ever
# fails to find it, add: p4a.branch = develop
android.enable_androidx = True

[buildozer]
log_level = 2
warn_on_root = 1
