"""
ai_engine.py
------------
Thin coordinator that the UI talks to. Decides *what* to do
(pick a move at the appropriate difficulty) while delegating the
*how* to search.py. Keeping this separate from search.py means the
recursive algorithm stays easy to read/test on its own, and this file
stays easy to explain in a viva: "this is the difficulty selector".
"""

import random
import chess
from chess_engine.search import find_best_move

# Difficulty -> search depth. Kept shallow enough to stay responsive
# on a phone; deeper levels take noticeably longer per move.
DIFFICULTY_DEPTH = {
    "easy": 2,
    "medium": 3,
    "hard": 4,
}

# On Easy, add a bit of randomness among near-best moves so the AI
# doesn't feel robotic/perfect for beginners.
EASY_RANDOMNESS_WINDOW = 50  # centipawns


class AIEngine:
    def __init__(self, difficulty="medium"):
        self.set_difficulty(difficulty)

    def set_difficulty(self, difficulty: str):
        difficulty = difficulty.lower()
        if difficulty not in DIFFICULTY_DEPTH:
            difficulty = "medium"
        self.difficulty = difficulty
        self.depth = DIFFICULTY_DEPTH[difficulty]

    def pick_move(self, board: chess.Board):
        """Return the chosen chess.Move for the current position. This
        is a (potentially slow) blocking call -- the UI layer is
        responsible for running it on a background thread."""
        if self.difficulty == "easy":
            return self._pick_easy_move(board)

        move, _score = find_best_move(board, self.depth)
        if move is None:
            # Fallback safety net -- should not normally happen if the
            # game isn't already over.
            legal = list(board.legal_moves)
            move = random.choice(legal) if legal else None
        return move

    def _pick_easy_move(self, board: chess.Board):
        """Search at shallow depth, then pick randomly among moves
        that are within EASY_RANDOMNESS_WINDOW centipawns of the best
        move, so Easy mode plays sensibly but not perfectly."""
        from chess_engine.search import minimax

        maximizing = board.turn == chess.WHITE
        scored_moves = []
        for move in board.legal_moves:
            board.push(move)
            score = minimax(board, self.depth - 1, float("-inf"), float("inf"), not maximizing)
            board.pop()
            scored_moves.append((move, score))

        if not scored_moves:
            return None

        if maximizing:
            best_score = max(s for _, s in scored_moves)
            candidates = [m for m, s in scored_moves if best_score - s <= EASY_RANDOMNESS_WINDOW]
        else:
            best_score = min(s for _, s in scored_moves)
            candidates = [m for m, s in scored_moves if s - best_score <= EASY_RANDOMNESS_WINDOW]

        return random.choice(candidates)
