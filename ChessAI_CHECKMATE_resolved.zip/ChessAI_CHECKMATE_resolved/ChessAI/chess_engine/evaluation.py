"""
evaluation.py
-------------
Static evaluation of a chess.Board position, from White's perspective
(positive = good for White, negative = good for Black). This is what
gives the AI "chess knowledge" -- Minimax alone just knows how to
search, this file tells it what a good position looks like.

Factors considered (per project spec):
  - Material value
  - Piece-square positioning
  - Mobility
  - King safety
  - Pawn structure
  - Center control
"""

import chess

# Standard material values (centipawns).
PIECE_VALUES = {
    chess.PAWN: 100,
    chess.KNIGHT: 320,
    chess.BISHOP: 330,
    chess.ROOK: 500,
    chess.QUEEN: 900,
    chess.KING: 0,  # king safety handled separately, not material
}

# Piece-square tables (from White's point of view; rank 0 = White's
# back rank). These are standard, widely-used simplified tables that
# nudge pieces toward good squares (knights toward the center, pawns
# toward promotion, king toward safety in the opening/middlegame).
PAWN_TABLE = [
      0,  0,  0,  0,  0,  0,  0,  0,
      5, 10, 10,-20,-20, 10, 10,  5,
      5, -5,-10,  0,  0,-10, -5,  5,
      0,  0,  0, 20, 20,  0,  0,  0,
      5,  5, 10, 25, 25, 10,  5,  5,
     10, 10, 20, 30, 30, 20, 10, 10,
     50, 50, 50, 50, 50, 50, 50, 50,
      0,  0,  0,  0,  0,  0,  0,  0,
]

KNIGHT_TABLE = [
    -50,-40,-30,-30,-30,-30,-40,-50,
    -40,-20,  0,  5,  5,  0,-20,-40,
    -30,  5, 10, 15, 15, 10,  5,-30,
    -30,  0, 15, 20, 20, 15,  0,-30,
    -30,  5, 15, 20, 20, 15,  5,-30,
    -30,  0, 10, 15, 15, 10,  0,-30,
    -40,-20,  0,  0,  0,  0,-20,-40,
    -50,-40,-30,-30,-30,-30,-40,-50,
]

BISHOP_TABLE = [
    -20,-10,-10,-10,-10,-10,-10,-20,
    -10,  5,  0,  0,  0,  0,  5,-10,
    -10, 10, 10, 10, 10, 10, 10,-10,
    -10,  0, 10, 10, 10, 10,  0,-10,
    -10,  5,  5, 10, 10,  5,  5,-10,
    -10,  0,  5, 10, 10,  5,  0,-10,
    -10,  0,  0,  0,  0,  0,  0,-10,
    -20,-10,-10,-10,-10,-10,-10,-20,
]

ROOK_TABLE = [
      0,  0,  0,  5,  5,  0,  0,  0,
     -5,  0,  0,  0,  0,  0,  0, -5,
     -5,  0,  0,  0,  0,  0,  0, -5,
     -5,  0,  0,  0,  0,  0,  0, -5,
     -5,  0,  0,  0,  0,  0,  0, -5,
     -5,  0,  0,  0,  0,  0,  0, -5,
      5, 10, 10, 10, 10, 10, 10,  5,
      0,  0,  0,  0,  0,  0,  0,  0,
]

QUEEN_TABLE = [
    -20,-10,-10, -5, -5,-10,-10,-20,
    -10,  0,  5,  0,  0,  0,  0,-10,
    -10,  5,  5,  5,  5,  5,  0,-10,
      0,  0,  5,  5,  5,  5,  0, -5,
     -5,  0,  5,  5,  5,  5,  0, -5,
    -10,  0,  5,  5,  5,  5,  0,-10,
    -10,  0,  0,  0,  0,  0,  0,-10,
    -20,-10,-10, -5, -5,-10,-10,-20,
]

KING_MIDGAME_TABLE = [
     20, 30, 10,  0,  0, 10, 30, 20,
     20, 20,  0,  0,  0,  0, 20, 20,
    -10,-20,-20,-20,-20,-20,-20,-10,
    -20,-30,-30,-40,-40,-30,-30,-20,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
]

PIECE_SQUARE_TABLES = {
    chess.PAWN: PAWN_TABLE,
    chess.KNIGHT: KNIGHT_TABLE,
    chess.BISHOP: BISHOP_TABLE,
    chess.ROOK: ROOK_TABLE,
    chess.QUEEN: QUEEN_TABLE,
    chess.KING: KING_MIDGAME_TABLE,
}

CENTER_SQUARES = {chess.D4, chess.D5, chess.E4, chess.E5}


def _square_index_for_table(square, is_white):
    """Piece-square tables above are written from White's perspective
    with index 0 = a1. python-chess square 0 is also a1, but the
    tables are listed top-to-bottom visually (rank 8 down to rank 1),
    so we mirror for Black."""
    if is_white:
        return square
    return chess.square_mirror(square)


def evaluate(board: chess.Board) -> float:
    """Return a centipawn score from White's perspective."""
    if board.is_checkmate():
        # The side to move is checkmated -> bad for them.
        return -99999 if board.turn == chess.WHITE else 99999
    if board.is_stalemate() or board.is_insufficient_material():
        return 0

    score = 0.0

    for square, piece in board.piece_map().items():
        value = PIECE_VALUES[piece.piece_type]
        table = PIECE_SQUARE_TABLES[piece.piece_type]
        idx = _square_index_for_table(square, piece.color == chess.WHITE)
        positional = table[idx]

        if piece.color == chess.WHITE:
            score += value + positional
        else:
            score -= value + positional

    score += _mobility_score(board)
    score += _king_safety_score(board)
    score += _pawn_structure_score(board)
    score += _center_control_score(board)

    return score


def _mobility_score(board: chess.Board) -> float:
    """Reward having more legal moves available (flexibility)."""
    white_moves = 0
    black_moves = 0
    turn_backup = board.turn

    board.turn = chess.WHITE
    white_moves = board.legal_moves.count()
    board.turn = chess.BLACK
    black_moves = board.legal_moves.count()

    board.turn = turn_backup
    return 2 * (white_moves - black_moves)


def _king_safety_score(board: chess.Board) -> float:
    """Simple king-safety heuristic: bonus for having pawns sheltering
    the king (pawn shield) in front of it."""
    score = 0.0
    for color, sign in ((chess.WHITE, 1), (chess.BLACK, -1)):
        king_sq = board.king(color)
        if king_sq is None:
            continue
        king_file = chess.square_file(king_sq)
        king_rank = chess.square_rank(king_sq)
        shield_rank = king_rank + 1 if color == chess.WHITE else king_rank - 1
        if 0 <= shield_rank <= 7:
            for f in (king_file - 1, king_file, king_file + 1):
                if 0 <= f <= 7:
                    sq = chess.square(f, shield_rank)
                    piece = board.piece_at(sq)
                    if piece and piece.piece_type == chess.PAWN and piece.color == color:
                        score += sign * 10
    return score


def _pawn_structure_score(board: chess.Board) -> float:
    """Penalize doubled and isolated pawns."""
    score = 0.0
    for color, sign in ((chess.WHITE, 1), (chess.BLACK, -1)):
        files_with_pawns = [0] * 8
        for square in board.pieces(chess.PAWN, color):
            files_with_pawns[chess.square_file(square)] += 1

        for f in range(8):
            count = files_with_pawns[f]
            if count > 1:
                score -= sign * 10 * (count - 1)  # doubled pawns
            if count > 0:
                left = files_with_pawns[f - 1] if f > 0 else 0
                right = files_with_pawns[f + 1] if f < 7 else 0
                if left == 0 and right == 0:
                    score -= sign * 8  # isolated pawn
    return score


def _center_control_score(board: chess.Board) -> float:
    """Bonus for occupying or attacking the center squares."""
    score = 0.0
    for square in CENTER_SQUARES:
        piece = board.piece_at(square)
        if piece:
            score += 8 if piece.color == chess.WHITE else -8
        if board.is_attacked_by(chess.WHITE, square):
            score += 3
        if board.is_attacked_by(chess.BLACK, square):
            score -= 3
    return score
