"""
search.py
---------
Minimax search with Alpha-Beta pruning over a python-chess Board.
This file only knows how to *search* -- it calls evaluation.evaluate()
for leaf-node scoring and doesn't know anything about the UI.

Move ordering (captures/checks first) is used to make alpha-beta
pruning cut off more branches early, which matters a lot when running
on a phone CPU at limited depth.
"""

import chess
from chess_engine.evaluation import evaluate


def _order_moves(board: chess.Board):
    """Return legal moves with captures and checks first, since
    examining strong moves first lets alpha-beta prune more nodes."""
    moves = list(board.legal_moves)

    def move_score(move):
        score = 0
        if board.is_capture(move):
            score += 10
        if board.gives_check(move):
            score += 5
        return score

    moves.sort(key=move_score, reverse=True)
    return moves


def minimax(board: chess.Board, depth: int, alpha: float, beta: float,
            maximizing: bool, nodes_counter=None) -> float:
    """Return the evaluated score of `board` searched `depth` plies
    deep, from White's perspective, using alpha-beta pruning.

    maximizing=True means it's White's turn to pick the best (highest)
    score; False means Black is picking the lowest score.
    """
    if nodes_counter is not None:
        nodes_counter[0] += 1

    if depth == 0 or board.is_game_over():
        return evaluate(board)

    if maximizing:
        best = float("-inf")
        for move in _order_moves(board):
            board.push(move)
            score = minimax(board, depth - 1, alpha, beta, False, nodes_counter)
            board.pop()
            best = max(best, score)
            alpha = max(alpha, best)
            if beta <= alpha:
                break  # beta cutoff
        return best
    else:
        best = float("inf")
        for move in _order_moves(board):
            board.push(move)
            score = minimax(board, depth - 1, alpha, beta, True, nodes_counter)
            board.pop()
            best = min(best, score)
            beta = min(beta, best)
            if beta <= alpha:
                break  # alpha cutoff
        return best


def find_best_move(board: chess.Board, depth: int):
    """Search all legal moves at the root and return the best one for
    the side to move (a chess.Move object), along with its score."""
    maximizing = board.turn == chess.WHITE
    best_move = None
    best_score = float("-inf") if maximizing else float("inf")
    alpha, beta = float("-inf"), float("inf")

    for move in _order_moves(board):
        board.push(move)
        score = minimax(board, depth - 1, alpha, beta, not maximizing)
        board.pop()

        if maximizing and score > best_score:
            best_score = score
            best_move = move
            alpha = max(alpha, best_score)
        elif not maximizing and score < best_score:
            best_score = score
            best_move = move
            beta = min(beta, best_score)

    return best_move, best_score
