"""
board_manager.py
-----------------
Wraps the python-chess Board object and exposes a simple, UI-friendly
API for the rest of the app. This is the single source of truth for
game state: whose turn it is, what moves are legal, move history,
undo, and game-over detection.

Keeping this as its own module means the UI code never has to know
anything about the python-chess library directly -- it only talks to
BoardManager. That makes the UI easier to test and easier to explain
in a viva ("the UI never touches chess rules directly").
"""

import chess


class BoardManager:
    def __init__(self):
        self.board = chess.Board()
        # Keep our own move history as SAN strings for the move-history panel.
        self.san_history = []
        # Stack of captured piece symbols, in the order they were captured.
        self.captured_white = []  # pieces WHITE captured (i.e. black pieces taken)
        self.captured_black = []  # pieces BLACK captured (i.e. white pieces taken)
        # Parallel log, one entry per applied move (same length as
        # san_history / board.move_stack), recording which capture
        # list (if any) that move appended to. Lets undo() pop the
        # exact matching entry back off instead of guessing.
        # Each entry is None (no capture) or "white"/"black".
        self._capture_log = []

    # ------------------------------------------------------------------
    # Move handling
    # ------------------------------------------------------------------
    def legal_moves_from(self, square_name):
        """Return a list of chess.Move objects that start at the given
        square name (e.g. 'e2'). Used by the UI to highlight legal
        destination squares after a piece is tapped."""
        square = chess.parse_square(square_name)
        return [m for m in self.board.legal_moves if m.from_square == square]

    def is_promotion(self, from_square_name, to_square_name):
        """Check whether a pending move would be a pawn promotion, so
        the UI can pop up a piece-choice dialog before actually pushing
        the move."""
        from_sq = chess.parse_square(from_square_name)
        to_sq = chess.parse_square(to_square_name)
        piece = self.board.piece_at(from_sq)
        if piece is None or piece.piece_type != chess.PAWN:
            return False
        rank = chess.square_rank(to_sq)
        return rank == 7 or rank == 0

    def make_move(self, from_square_name, to_square_name, promotion=None):
        """Attempt to make a move. Returns True if the move was legal
        and applied, False otherwise. `promotion` should be one of
        'q', 'r', 'b', 'n' when relevant."""
        from_sq = chess.parse_square(from_square_name)
        to_sq = chess.parse_square(to_square_name)

        promo_piece = None
        if promotion:
            promo_piece = {"q": chess.QUEEN, "r": chess.ROOK,
                            "b": chess.BISHOP, "n": chess.KNIGHT}.get(promotion)

        move = chess.Move(from_sq, to_sq, promotion=promo_piece)

        if move not in self.board.legal_moves:
            return False

        self._capture_log.append(self._record_capture(move))
        san = self.board.san(move)
        self.board.push(move)
        self.san_history.append(san)
        return True

    def push_uci_move(self, move):
        """Push a chess.Move object directly (used by the AI, which
        already produces a legal chess.Move)."""
        if move not in self.board.legal_moves:
            return False
        self._capture_log.append(self._record_capture(move))
        san = self.board.san(move)
        self.board.push(move)
        self.san_history.append(san)
        return True

    def _record_capture(self, move):
        """Apply the capture (if any) to the appropriate captured-piece
        list and return which list it went to ("white", "black", or
        None), so undo() can reverse exactly this move's effect."""
        if not self.board.is_capture(move):
            return None
        captured_square = move.to_square
        # En passant captures land on an empty square, the actual
        # captured pawn is one rank behind/ahead.
        if self.board.is_en_passant(move):
            captured_square = move.to_square + (-8 if self.board.turn == chess.WHITE else 8)
        captured_piece = self.board.piece_at(captured_square)
        if not captured_piece:
            return None
        symbol = captured_piece.symbol()
        if self.board.turn == chess.WHITE:
            self.captured_white.append(symbol)
            return "white"
        else:
            self.captured_black.append(symbol)
            return "black"

    def undo(self):
        """Undo the last move, fully restoring board position, SAN
        history, and captured-piece lists to their prior state.
        Returns True if a move was undone, False if there was nothing
        to undo."""
        if not self.board.move_stack:
            return False
        self.board.pop()
        if self.san_history:
            self.san_history.pop()
        if self._capture_log:
            capture_entry = self._capture_log.pop()
            if capture_entry == "white" and self.captured_white:
                self.captured_white.pop()
            elif capture_entry == "black" and self.captured_black:
                self.captured_black.pop()
        return True

    def reset(self):
        self.board = chess.Board()
        self.san_history = []
        self.captured_white = []
        self.captured_black = []
        self._capture_log = []

    # ------------------------------------------------------------------
    # State queries
    # ------------------------------------------------------------------
    def turn_is_white(self):
        return self.board.turn == chess.WHITE

    def is_check(self):
        return self.board.is_check()

    def is_checkmate(self):
        return self.board.is_checkmate()

    def is_stalemate(self):
        return self.board.is_stalemate()

    def is_draw(self):
        return (self.board.is_insufficient_material()
                or self.board.is_seventyfive_moves()
                or self.board.is_fivefold_repetition()
                or self.board.is_stalemate())

    def is_game_over(self):
        return self.board.is_game_over()

    def result(self):
        return self.board.result()

    def king_square_in_check(self):
        """Return the square name of the king currently in check, or
        None. Used by the UI to highlight the checked king."""
        if not self.board.is_check():
            return None
        king_square = self.board.king(self.board.turn)
        return chess.square_name(king_square)

    def last_move_squares(self):
        """Return (from_square_name, to_square_name) of the last move,
        or None if no moves have been made."""
        if not self.board.move_stack:
            return None
        last = self.board.move_stack[-1]
        return chess.square_name(last.from_square), chess.square_name(last.to_square)

    def piece_map(self):
        """Return {square_name: (piece_symbol, is_white)} for every
        occupied square, for the UI to render."""
        result = {}
        for square, piece in self.board.piece_map().items():
            result[chess.square_name(square)] = (piece.symbol().upper(), piece.color == chess.WHITE)
        return result

    def move_count(self):
        return len(self.san_history)
