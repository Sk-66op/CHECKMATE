"""
move_manager.py
----------------
Orchestrates a single game session: owns a BoardManager, optionally an
AIEngine, and knows the game mode (PvP or PvAI) and which color the
human is playing. The UI (game_screen.py) talks only to this class,
which keeps threading concerns (running the AI off the main thread)
out of the UI code and out of the pure chess logic.
"""

import threading
import chess
from kivy.clock import Clock

from chess_engine.board_manager import BoardManager
from chess_engine.ai_engine import AIEngine


class MoveManager:
    def __init__(self, mode="pvp", human_is_white=True, ai_difficulty="medium"):
        """
        mode: "pvp" or "pva"
        human_is_white: only relevant for "pva" mode
        """
        self.mode = mode
        self.human_is_white = human_is_white
        self.board_manager = BoardManager()
        self.ai_engine = AIEngine(ai_difficulty) if mode == "pva" else None
        self.ai_thinking = False
        self.game_over = False
        self._game_generation = 0
        self._active = True

        # Callbacks the UI can set to react to state changes.
        self.on_ai_move_start = None   # called right before AI starts thinking
        self.on_ai_move_end = None     # called after AI move is applied
        self.on_game_over = None       # called with a result string

    # ------------------------------------------------------------------
    def is_human_turn(self):
        if self.mode == "pvp":
            return True
        white_to_move = self.board_manager.turn_is_white()
        return white_to_move == self.human_is_white

    def maybe_start_ai_turn(self):
        """Call once right after a new game is set up. If the AI moves
        first (human chose Black), kicks off its move immediately so
        White's opening move isn't left un-played. Safe to call in any
        mode/state -- it only acts when it's genuinely the AI's turn
        and the game isn't already over."""
        if self.mode != "pva":
            return
        if self.is_game_over():
            return
        if not self.is_human_turn():
            self._trigger_ai_move()

    def attempt_human_move(self, from_sq, to_sq, promotion=None):
        """Try to apply a human move. Returns True if it was legal and
        applied. Triggers the AI's reply automatically in PvA mode."""
        if self.is_game_over():
            return False
        if self.ai_thinking:
            return False
        if not self.is_human_turn():
            return False

        applied = self.board_manager.make_move(from_sq, to_sq, promotion)
        if not applied:
            return False

        self._check_game_over()

        if self.mode == "pva" and not self.is_game_over():
            self._trigger_ai_move()

        return True

    def _trigger_ai_move(self):
        """Kick off the AI's move calculation on a background thread so
        the UI stays responsive, then apply the result back on the
        main thread via Kivy's Clock."""
        if self.ai_thinking:
            return
        if self.is_game_over():
            return
        self.ai_thinking = True
        generation = self._game_generation

        if self.on_ai_move_start:
            self.on_ai_move_start()

        thread = threading.Thread(target=self._ai_worker, args=(generation,), daemon=True)
        thread.start()

    def _ai_worker(self, generation):
        board_copy = self.board_manager.board.copy()
        move = self.ai_engine.pick_move(board_copy)
        # Hand the result back to the main thread -- Kivy widgets must
        # only be touched from the main thread.
        Clock.schedule_once(lambda dt: self._apply_ai_move(move, generation), 0)

    def _apply_ai_move(self, move, generation):
        # Ignore a late result from an AI thread belonging to an older game
        # (for example after Restart or leaving the game screen).
        if not self._active or generation != self._game_generation:
            return
        self.ai_thinking = False
        if self.is_game_over():
            return
        if move is not None:
            self.board_manager.push_uci_move(move)
        self._check_game_over()
        if self.on_ai_move_end:
            self.on_ai_move_end(move)

    # ------------------------------------------------------------------
    def undo(self):
        """Undo the last move. In PvP mode this undoes a single ply.
        In PvA mode it keeps undoing (one ply at a time) until it's
        the human's turn again, or there's nothing left to undo --
        this correctly handles the case where the AI has made only
        one move so far (human plays Black) as well as the normal
        case of undoing a full human+AI round trip."""
        if self.ai_thinking:
            return False

        undone_any = False
        while True:
            undone = self.board_manager.undo()
            if not undone:
                break
            undone_any = True
            if self.mode != "pva" or self.is_human_turn():
                break
        return undone_any


    def close(self):
        """Invalidate pending AI work when the screen/game is abandoned."""
        self._active = False
        self._game_generation += 1
        self.ai_thinking = False

    def restart(self):
        self._game_generation += 1
        self.board_manager.reset()
        self.ai_thinking = False
        self.game_over = False

    def is_game_over(self):
        return self.game_over or self.board_manager.is_game_over()

    def resign(self):
        if self.is_game_over() or self.ai_thinking:
            return False
        winner = "Black" if self.board_manager.turn_is_white() else "White"
        self.game_over = True
        if self.on_game_over:
            self.on_game_over(f"{winner} wins by resignation")
        return True

    def _check_game_over(self):
        if not self.board_manager.is_game_over():
            return
        self.game_over = True
        if self.board_manager.is_checkmate():
            winner = "Black" if self.board_manager.turn_is_white() else "White"
            result = f"Checkmate — {winner} wins"
        elif self.board_manager.is_stalemate():
            result = "Draw by stalemate"
        else:
            result = f"Draw ({self.board_manager.result()})"
        if self.on_game_over:
            self.on_game_over(result)
