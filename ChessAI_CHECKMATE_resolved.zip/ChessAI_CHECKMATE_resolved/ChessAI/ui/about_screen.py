"""
about_screen.py
----------------
Simple informational screen for the project (name, purpose, tech
stack) -- useful to show during the viva as a quick project summary.
"""

from kivy.uix.screenmanager import Screen
from kivy.metrics import dp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.label import MDLabel

ABOUT_TEXT = (
    "CHECKMATE - Chess AI\n\n"
    "A 2nd-year B.Tech mini project.\n\n"
    "Built with Python, KivyMD and python-chess.\n"
    "The AI opponent uses Minimax search with Alpha-Beta pruning "
    "and a hand-written evaluation function considering material, "
    "piece-square positioning, mobility, king safety, pawn structure "
    "and center control.\n\n"
    "Features: Player vs AI (3 difficulty levels), local Player vs "
    "Player, full rule support (castling, en passant, promotion), "
    "move history, undo, and persistent settings."
)


class AboutScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        root = MDBoxLayout(orientation="vertical", padding=dp(24), spacing=dp(16),
                            md_bg_color=(0.11, 0.13, 0.16, 1))

        root.add_widget(MDLabel(text="About", font_style="H4", size_hint_y=None,
                                 height=dp(50), theme_text_color="Custom",
                                 text_color=(0.93, 0.86, 0.72, 1)))

        body = MDLabel(text=ABOUT_TEXT, theme_text_color="Custom",
                        text_color=(0.85, 0.85, 0.85, 1))
        root.add_widget(body)

        back_btn = MDRaisedButton(text="Back", size_hint=(1, None), height=dp(50))
        back_btn.bind(on_release=lambda *_: self._go_back())
        root.add_widget(back_btn)

        self.add_widget(root)

    def _go_back(self):
        self.manager.current = "home"
