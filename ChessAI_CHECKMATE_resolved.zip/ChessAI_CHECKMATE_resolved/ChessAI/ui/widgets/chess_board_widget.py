"""
chess_board_widget.py
----------------------
The interactive 8x8 board. Pure Kivy widget, drawn entirely on the
Canvas so it scales cleanly to any Android screen size (no fixed
pixel assets required to lay out the grid itself).

3D-LOOK PIECES (no real 3D / no OpenGL):
Each piece is a Unicode chess glyph (♔♕♖♗♘♙ etc.) rendered three
times per square, layered like this:
  1. A soft dark offset "shadow" glyph, drawn slightly down-and-right
     and semi-transparent -- gives the piece a sense of lifting off
     the board.
  2. The main glyph in the piece's color.
  3. A small bright highlight glyph, drawn slightly up-and-left and
     more transparent, only a couple of pixels offset -- simulates a
     glossy top-light catching the piece.
This "shadow + base + highlight" trick is a classic 2D fake-3D/glossy
effect and needs no extra image assets. If you later want to swap in
real piece PNG artwork (e.g. from assets/pieces/), replace
`_draw_piece_glyph` with an `Image`/texture draw using the same
three-layer shadow/highlight offsets for a consistent look.
"""

from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle
from kivy.core.text import Label as CoreLabel
from kivy.graphics.texture import Texture

FILES = "abcdefgh"

UNICODE_PIECES = {
    ("K", True): "\u2654", ("Q", True): "\u2655", ("R", True): "\u2656",
    ("B", True): "\u2657", ("N", True): "\u2658", ("P", True): "\u2659",
    ("K", False): "\u265A", ("Q", False): "\u265B", ("R", False): "\u265C",
    ("B", False): "\u265D", ("N", False): "\u265E", ("P", False): "\u265F",
}

LIGHT_SQUARE = (0.93, 0.86, 0.72, 1)
DARK_SQUARE = (0.55, 0.36, 0.24, 1)
SELECTED_COLOR = (0.95, 0.85, 0.25, 0.55)
LEGAL_MOVE_COLOR = (0.15, 0.65, 0.25, 0.55)
LAST_MOVE_COLOR = (0.95, 0.6, 0.1, 0.35)
CHECK_COLOR = (0.9, 0.1, 0.1, 0.55)


class ChessBoardWidget(Widget):
    """Renders the board + pieces and reports taps back to the game
    screen via `on_square_tapped(square_name)`. Does not know chess
    rules itself -- it just displays whatever state it's given."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.piece_positions = {}       # {square_name: (symbol, is_white)}
        self.selected_square = None
        self.legal_targets = []         # list of square names
        self.last_move = None           # (from_sq, to_sq) or None
        self.check_square = None        # square name of king in check, or None
        self.on_square_tapped = None    # callback set by game_screen
        self.flipped = False            # True to show Black at bottom

        self._glyph_cache = {}

        self.bind(pos=self._redraw, size=self._redraw)

    # ------------------------------------------------------------------
    def set_board_state(self, piece_positions, selected_square=None,
                         legal_targets=None, last_move=None, check_square=None):
        self.piece_positions = piece_positions
        self.selected_square = selected_square
        self.legal_targets = legal_targets or []
        self.last_move = last_move
        self.check_square = check_square
        self._redraw()

    def square_size(self):
        return min(self.width, self.height) / 8.0

    def _square_to_screen(self, square_name):
        """Convert 'e4' style square name to the bottom-left pixel
        coordinate of that square on screen, respecting board flip."""
        file_idx = FILES.index(square_name[0])
        rank_idx = int(square_name[1]) - 1

        if self.flipped:
            file_idx = 7 - file_idx
            rank_idx = 7 - rank_idx

        size = self.square_size()
        x = self.x + file_idx * size
        y = self.y + rank_idx * size
        return x, y

    def _screen_to_square(self, x, y):
        size = self.square_size()
        file_idx = int((x - self.x) // size)
        rank_idx = int((y - self.y) // size)
        if not (0 <= file_idx <= 7 and 0 <= rank_idx <= 7):
            return None
        if self.flipped:
            file_idx = 7 - file_idx
            rank_idx = 7 - rank_idx
        return f"{FILES[file_idx]}{rank_idx + 1}"

    # ------------------------------------------------------------------
    def on_touch_down(self, touch):
        if not self.collide_point(*touch.pos):
            return False
        square = self._screen_to_square(*touch.pos)
        if square and self.on_square_tapped:
            self.on_square_tapped(square)
        return True

    # ------------------------------------------------------------------
    def _redraw(self, *args):
        self.canvas.clear()
        size = self.square_size()

        with self.canvas:
            # Squares
            for file_idx in range(8):
                for rank_idx in range(8):
                    is_light = (file_idx + rank_idx) % 2 == 1
                    Color(*(LIGHT_SQUARE if is_light else DARK_SQUARE))
                    sx = self.x + file_idx * size
                    sy = self.y + rank_idx * size
                    Rectangle(pos=(sx, sy), size=(size, size))

            # Highlight overlays (check, last move, selected, legal targets)
            if self.check_square:
                self._draw_overlay(self.check_square, CHECK_COLOR, size)
            if self.last_move:
                for sq in self.last_move:
                    self._draw_overlay(sq, LAST_MOVE_COLOR, size)
            if self.selected_square:
                self._draw_overlay(self.selected_square, SELECTED_COLOR, size)
            for sq in self.legal_targets:
                self._draw_overlay(sq, LEGAL_MOVE_COLOR, size)

            # Pieces (with pseudo-3D shadow/highlight layering)
            for square_name, (symbol, is_white) in self.piece_positions.items():
                self._draw_piece_glyph(square_name, symbol, is_white, size)

    def _draw_overlay(self, square_name, color, size):
        x, y = self._square_to_screen(square_name)
        Color(*color)
        Rectangle(pos=(x, y), size=(size, size))

    def _draw_piece_glyph(self, square_name, symbol, is_white, size):
        x, y = self._square_to_screen(square_name)
        glyph = UNICODE_PIECES[(symbol, is_white)]
        font_size = int(size * 0.72)

        texture = self._glyph_texture(glyph, font_size)
        tex_w, tex_h = texture.size
        draw_x = x + (size - tex_w) / 2
        draw_y = y + (size - tex_h) / 2
        offset = max(1, size * 0.02)

        # 1. Shadow layer (down-right, dark, semi-transparent)
        Color(0, 0, 0, 0.35)
        Rectangle(texture=texture, pos=(draw_x + offset, draw_y - offset), size=(tex_w, tex_h))

        # 2. Base glyph, full color
        Color(1, 1, 1, 1)
        Rectangle(texture=texture, pos=(draw_x, draw_y), size=(tex_w, tex_h))

        # 3. Highlight layer (up-left, bright, subtle) -- only for
        # white pieces where it reads clearly against the glyph fill.
        if is_white:
            Color(1, 1, 1, 0.25)
            Rectangle(texture=texture, pos=(draw_x - offset * 0.6, draw_y + offset * 0.6),
                       size=(tex_w, tex_h))

    def _glyph_texture(self, glyph, font_size):
        """Cache rendered glyph textures per (glyph, font_size) so we
        don't re-rasterize text every single frame redraw."""
        key = (glyph, font_size)
        if key not in self._glyph_cache:
            label = CoreLabel(text=glyph, font_size=font_size)
            label.refresh()
            self._glyph_cache[key] = label.texture
        return self._glyph_cache[key]
