"""
Sleek 2026 Dark UI for ChessAI Game Screen
Compatible with Kivy 2.3+, KivyMD 1.2+, and Buildozer Android APKs.
"""

from kivy.lang import Builder
from kivy.properties import BooleanProperty, NumericProperty, StringProperty, ObjectProperty, ListProperty
from kivy.clock import Clock
from kivy.animation import Animation
from kivy.graphics import Color, RoundedRectangle, Line
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton, MDRaisedButton, MDFlatButton
from kivymd.uix.label import MDLabel
from kivymd.uix.dialog import MDDialog
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.bottomsheet import MDModalBottomSheet

# KV Layout Definition with High-Precision Glassmorphism & Cyberpunk Theme
KV_GAME_SCREEN = """
#:import hex kivy.utils.get_color_from_hex

<SleekGlassCard@MDCard>:
    elevation: 0
    radius: [dp(16), dp(16), dp(16), dp(16)]
    md_bg_color: hex("#151923")
    canvas.after:
        Color:
            rgba: [1, 1, 1, 0.06]
        Line:
            rounded_rectangle: [self.x, self.y, self.width, self.height, dp(16)]
            width: dp(1)

<CircularActionButton@MDCard>:
    size_hint: None, None
    size: dp(54), dp(54)
    radius: [dp(27), dp(27), dp(27), dp(27)]
    elevation: 0
    md_bg_color: hex("#151923")
    icon_name: "play"
    label_text: ""
    is_danger: False
    disabled_state: False
    on_release: root.on_action_click() if hasattr(root, 'on_action_click') else None
    canvas.after:
        Color:
            rgba: [1, 1, 1, 0.08] if not self.is_danger else hex("#FF4C6A80")
        Line:
            rounded_rectangle: [self.x, self.y, self.width, self.height, dp(27)]
            width: dp(1)

<GameScreen>:
    name: "game_screen"
    md_bg_color: hex("#080A0F")

    MDBoxLayout:
        orientation: "vertical"
        padding: [dp(16), dp(12), dp(16), dp(12)]
        spacing: dp(10)

        # -------------------------------------------------------------
        # 1. TOP APP BAR (Back, Sleek Logo Badge, More Options)
        # -------------------------------------------------------------
        MDBoxLayout:
            size_hint_y: None
            height: dp(48)
            spacing: dp(12)
            adaptive_height: True

            MDIconButton:
                icon: "arrow-left"
                theme_icon_color: "Custom"
                icon_color: hex("#F4F6FA")
                size_hint: None, None
                size: dp(40), dp(40)
                md_bg_color: hex("#151923")
                on_release: root.on_back_pressed()

            MDBoxLayout:
                spacing: dp(8)
                adaptive_height: True
                pos_hint: {"center_y": 0.5}

                # Mini Gradient Badge
                MDCard:
                    size_hint: None, None
                    size: dp(28), dp(28)
                    radius: [dp(7), dp(7), dp(7), dp(7)]
                    md_bg_color: hex("#00E5FF")
                    elevation: 0
                    MDLabel:
                        text: "C"
                        halign: "center"
                        valign: "center"
                        theme_text_color: "Custom"
                        text_color: hex("#080A0F")
                        bold: True
                        font_style: "H6"

                MDLabel:
                    text: "CHESSAI"
                    font_style: "Subtitle1"
                    bold: True
                    theme_text_color: "Custom"
                    text_color: hex("#F4F6FA")
                    letter_spacing: "2.5sp"
                    pos_hint: {"center_y": 0.5}

            Widget:

            MDIconButton:
                id: menu_btn
                icon: "dots-vertical"
                theme_icon_color: "Custom"
                icon_color: hex("#F4F6FA")
                size_hint: None, None
                size: dp(40), dp(40)
                md_bg_color: hex("#151923")
                on_release: root.open_overflow_menu(self)

        # -------------------------------------------------------------
        # 2. OPPONENT CARD (AI / Black)
        # -------------------------------------------------------------
        SleekGlassCard:
            size_hint_y: None
            height: dp(68)
            padding: [dp(12), dp(8), dp(12), dp(8)]

            MDBoxLayout:
                spacing: dp(12)

                # Opponent Avatar Capsule
                MDCard:
                    size_hint: None, None
                    size: dp(46), dp(46)
                    radius: [dp(12), dp(12), dp(12), dp(12)]
                    md_bg_color: hex("#1F2633")
                    elevation: 0
                    pos_hint: {"center_y": 0.5}
                    MDLabel:
                        text: "♟"
                        halign: "center"
                        font_style: "H5"
                        theme_text_color: "Custom"
                        text_color: hex("#F4F6FA")

                MDBoxLayout:
                    orientation: "vertical"
                    spacing: dp(2)
                    pos_hint: {"center_y": 0.5}

                    MDBoxLayout:
                        spacing: dp(6)
                        adaptive_height: True

                        MDLabel:
                            text: root.opponent_name
                            font_style: "Subtitle2"
                            bold: True
                            theme_text_color: "Custom"
                            text_color: hex("#F4F6FA")
                            adaptive_size: True

                        # Difficulty pill tag
                        MDCard:
                            size_hint: None, None
                            size: dp(54), dp(18)
                            radius: [dp(4), dp(4), dp(4), dp(4)]
                            md_bg_color: hex("#00E5FF26")
                            elevation: 0
                            MDLabel:
                                text: root.opponent_difficulty
                                halign: "center"
                                font_style: "Caption"
                                bold: True
                                theme_text_color: "Custom"
                                text_color: hex("#00E5FF")

                    MDLabel:
                        text: "THINKING..." if root.is_ai_thinking else root.opponent_subtitle
                        font_style: "Caption"
                        theme_text_color: "Custom"
                        text_color: hex("#00E5FF") if root.is_ai_thinking else hex("#94A3B8")

                Widget:

                # Opponent Clock
                MDBoxLayout:
                    orientation: "vertical"
                    adaptive_size: True
                    pos_hint: {"center_y": 0.5}

                    MDLabel:
                        text: "TIME"
                        font_style: "Overline"
                        theme_text_color: "Custom"
                        text_color: hex("#94A3B8")
                        halign: "right"

                    MDLabel:
                        text: root.opponent_time_text
                        font_style: "H6"
                        bold: True
                        theme_text_color: "Custom"
                        text_color: hex("#F4F6FA") if not root.is_opponent_low_time else hex("#FF4C6A")
                        halign: "right"

        # -------------------------------------------------------------
        # 3. CHESS BOARD CONTAINER (1:1 Hero Widget)
        # -------------------------------------------------------------
        MDBoxLayout:
            id: board_container
            size_hint: 1, 1
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            padding: dp(4)

            # The ChessBoardWidget is injected dynamically here

        # -------------------------------------------------------------
        # 4. CAPTURED PIECES & EVALUATION STRIP
        # -------------------------------------------------------------
        MDCard:
            size_hint_y: None
            height: dp(32)
            radius: [dp(8), dp(8), dp(8), dp(8)]
            md_bg_color: hex("#0E121B")
            elevation: 0
            padding: [dp(12), dp(4), dp(12), dp(4)]

            MDBoxLayout:
                spacing: dp(8)
                MDLabel:
                    text: "CAPTURES:"
                    font_style: "Caption"
                    bold: True
                    theme_text_color: "Custom"
                    text_color: hex("#64748B")
                    adaptive_size: True
                    pos_hint: {"center_y": 0.5}

                MDLabel:
                    id: captured_pieces_label
                    text: root.captured_text
                    font_style: "Body2"
                    theme_text_color: "Custom"
                    text_color: hex("#E2E8F0")
                    pos_hint: {"center_y": 0.5}

                Widget:

                MDLabel:
                    text: root.eval_score_text
                    font_style: "Caption"
                    bold: True
                    theme_text_color: "Custom"
                    text_color: hex("#00E5FF")
                    adaptive_size: True
                    pos_hint: {"center_y": 0.5}

        # -------------------------------------------------------------
        # 5. PLAYER CARD (YOU / White)
        # -------------------------------------------------------------
        SleekGlassCard:
            id: player_card
            size_hint_y: None
            height: dp(68)
            padding: [dp(12), dp(8), dp(12), dp(8)]
            canvas.after:
                Color:
                    rgba: hex("#00E5FF4D") if root.is_player_turn else [1, 1, 1, 0.06]
                Line:
                    rounded_rectangle: [self.x, self.y, self.width, self.height, dp(16)]
                    width: dp(1.5) if root.is_player_turn else dp(1)

            MDBoxLayout:
                spacing: dp(12)

                # Player Avatar Capsule
                MDCard:
                    size_hint: None, None
                    size: dp(46), dp(46)
                    radius: [dp(12), dp(12), dp(12), dp(12)]
                    md_bg_color: hex("#1F2633")
                    elevation: 0
                    pos_hint: {"center_y": 0.5}
                    MDLabel:
                        text: "♙"
                        halign: "center"
                        font_style: "H5"
                        theme_text_color: "Custom"
                        text_color: hex("#00E5FF")

                MDBoxLayout:
                    orientation: "vertical"
                    spacing: dp(2)
                    pos_hint: {"center_y": 0.5}

                    MDBoxLayout:
                        spacing: dp(6)
                        adaptive_height: True

                        MDLabel:
                            text: "YOU"
                            font_style: "Subtitle2"
                            bold: True
                            theme_text_color: "Custom"
                            text_color: hex("#F4F6FA")
                            adaptive_size: True

                        MDLabel:
                            text: "WHITE" if root.player_color_white else "BLACK"
                            font_style: "Caption"
                            bold: True
                            theme_text_color: "Custom"
                            text_color: hex("#64748B")
                            adaptive_size: True

                    MDLabel:
                        text: "Your Turn" if root.is_player_turn else "Waiting..."
                        font_style: "Caption"
                        bold: True
                        theme_text_color: "Custom"
                        text_color: hex("#00E5FF") if root.is_player_turn else hex("#64748B")

                Widget:

                # Player Clock
                MDBoxLayout:
                    orientation: "vertical"
                    adaptive_size: True
                    pos_hint: {"center_y": 0.5}

                    MDLabel:
                        text: "TIME"
                        font_style: "Overline"
                        theme_text_color: "Custom"
                        text_color: hex("#94A3B8")
                        halign: "right"

                    MDLabel:
                        text: root.player_time_text
                        font_style: "H6"
                        bold: True
                        theme_text_color: "Custom"
                        text_color: hex("#F4F6FA") if not root.is_player_low_time else hex("#FF4C6A")
                        halign: "right"

        # -------------------------------------------------------------
        # 6. ACTION CONTROLS & MOVE HISTORY BAR
        # -------------------------------------------------------------
        MDBoxLayout:
            orientation: "vertical"
            spacing: dp(8)
            adaptive_height: True

            # Circular 48dp+ Action Buttons
            MDBoxLayout:
                adaptive_height: True
                spacing: dp(20)
                pos_hint: {"center_x": 0.5}

                Widget:

                # UNDO
                MDBoxLayout:
                    orientation: "vertical"
                    spacing: dp(2)
                    adaptive_size: True
                    MDIconButton:
                        icon: "undo"
                        theme_icon_color: "Custom"
                        icon_color: hex("#94A3B8") if not root.can_undo else hex("#F4F6FA")
                        md_bg_color: hex("#151923")
                        on_release: root.on_undo_click()
                    MDLabel:
                        text: "Undo"
                        font_style: "Caption"
                        halign: "center"
                        theme_text_color: "Custom"
                        text_color: hex("#94A3B8")

                # HINT
                MDBoxLayout:
                    orientation: "vertical"
                    spacing: dp(2)
                    adaptive_size: True
                    MDIconButton:
                        icon: "lightbulb-outline"
                        theme_icon_color: "Custom"
                        icon_color: hex("#00E5FF")
                        md_bg_color: hex("#151923")
                        on_release: root.on_hint_click()
                    MDLabel:
                        text: "Hint"
                        font_style: "Caption"
                        halign: "center"
                        theme_text_color: "Custom"
                        text_color: hex("#94A3B8")

                # RESIGN
                MDBoxLayout:
                    orientation: "vertical"
                    spacing: dp(2)
                    adaptive_size: True
                    MDIconButton:
                        icon: "flag-outline"
                        theme_icon_color: "Custom"
                        icon_color: hex("#FF4C6A")
                        md_bg_color: hex("#151923")
                        on_release: root.on_resign_click()
                    MDLabel:
                        text: "Resign"
                        font_style: "Caption"
                        halign: "center"
                        theme_text_color: "Custom"
                        text_color: hex("#FF4C6A")

                # MOVES
                MDBoxLayout:
                    orientation: "vertical"
                    spacing: dp(2)
                    adaptive_size: True
                    MDIconButton:
                        icon: "format-list-numbered"
                        theme_icon_color: "Custom"
                        icon_color: hex("#F4F6FA")
                        md_bg_color: hex("#151923")
                        on_release: root.open_move_history()
                    MDLabel:
                        text: "Moves"
                        font_style: "Caption"
                        halign: "center"
                        theme_text_color: "Custom"
                        text_color: hex("#94A3B8")

                Widget:

            # Bottom History Sheet Grab Handle Bar
            MDCard:
                size_hint: 1, None
                height: dp(34)
                radius: [dp(20), dp(20), 0, 0]
                md_bg_color: hex("#151923")
                elevation: 0
                on_release: root.open_move_history()

                MDBoxLayout:
                    orientation: "vertical"
                    spacing: dp(3)
                    pos_hint: {"center_x": 0.5, "center_y": 0.5}

                    # Drag handle line
                    MDCard:
                        size_hint: None, None
                        size: dp(32), dp(4)
                        radius: [dp(2), dp(2), dp(2), dp(2)]
                        md_bg_color: hex("#2A2E3A")
                        elevation: 0
                        pos_hint: {"center_x": 0.5}

                    MDLabel:
                        text: "MOVE HISTORY"
                        font_style: "Overline"
                        bold: True
                        theme_text_color: "Custom"
                        text_color: hex("#94A3B8")
                        halign: "center"
                        letter_spacing: "1.5sp"
"""

Builder.load_string(KV_GAME_SCREEN)


class GameScreen(MDScreen):
    # State observables
    opponent_name = StringProperty("CHESS AI")
    opponent_difficulty = StringProperty("HARD")
    opponent_subtitle = StringProperty("BLACK")
    is_ai_thinking = BooleanProperty(False)
    is_player_turn = BooleanProperty(True)
    player_color_white = BooleanProperty(True)
    can_undo = BooleanProperty(False)

    player_time_seconds = NumericProperty(600)  # 10 min default
    opponent_time_seconds = NumericProperty(600)
    player_time_text = StringProperty("10:00")
    opponent_time_text = StringProperty("10:00")
    is_player_low_time = BooleanProperty(False)
    is_opponent_low_time = BooleanProperty(False)

    captured_text = StringProperty("—")
    eval_score_text = StringProperty("+0.0")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.menu = None
        self.clock_event = None
        self.chess_board_widget = None

    def on_enter(self, *args):
        """Called when navigation transitions to this screen."""
        self.setup_board_widget()
        self.start_timer()

    def on_leave(self, *args):
        """Clean up background timers when leaving."""
        if self.clock_event:
            self.clock_event.cancel()

    def setup_board_widget(self):
        """Embeds your existing ChessBoardWidget dynamically."""
        if not self.chess_board_widget:
            try:
                from ui.widgets.chess_board_widget import ChessBoardWidget
                self.chess_board_widget = ChessBoardWidget()
                # Apply theme colors to your board widget if supported:
                if hasattr(self.chess_board_widget, "light_color"):
                    self.chess_board_widget.light_color = (0.82, 0.835, 0.86, 1.0) # #D1D5DB
                    self.chess_board_widget.dark_color = (0.215, 0.255, 0.318, 1.0) # #374151
                self.ids.board_container.add_widget(self.chess_board_widget)
            except Exception as e:
                print(f"[ChessAI] Board Widget injection note: {e}")

    def start_timer(self):
        """Tick game clocks every 1.0 second."""
        if self.clock_event:
            self.clock_event.cancel()
        self.clock_event = Clock.schedule_interval(self._timer_tick, 1.0)

    def _timer_tick(self, dt):
        if self.is_player_turn:
            if self.player_time_seconds > 0:
                self.player_time_seconds -= 1
                self.player_time_text = self._format