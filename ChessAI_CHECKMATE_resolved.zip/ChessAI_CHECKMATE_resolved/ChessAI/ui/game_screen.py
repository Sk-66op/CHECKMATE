"""
game_screen.py
---------------
The main gameplay screen. Hosts the ChessBoardWidget, move history
panel, captured-piece display, and control buttons (undo/restart/
resign/menu). Talks to MoveManager for all game logic -- this file
should contain UI wiring only, no chess rules.
"""

from kivy.uix.screenmanager import Screen
from kivy.metrics import dp
from kivy.clock import Clock
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.label import MDLabel
from kivymd.uix.dialog import MDDialog
from kivymd.uix.scrollview import MDScrollView

from ui.widgets.chess_board_widget import ChessBoardWidget
from chess_engine.move_manager import MoveManager


class GameScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.move_manager = None
        self.pending_mode = "pvp"
        self.dialog = None
        self._pending_promotion = None

        root = MDBoxLayout(orientation="vertical", md_bg_color=(0.11, 0.13, 0.16, 1))

        # --- Top info bar ---
        self.status_label = MDLabel(text="White to move", halign="center",
                                     size_hint_y=None, height=dp(36),
                                     theme_text_color="Custom", text_color=(0.9, 0.9, 0.9, 1))
        root.add_widget(self.status_label)

        # --- Captured pieces row ---
        self.captured_label = MDLabel(text="", halign="center", size_hint_y=None,
                                       height=dp(28), theme_text_color="Custom",
                                       text_color=(0.7, 0.7, 0.7, 1))
        root.add_widget(self.captured_label)

        # --- Board ---
        board_container = MDBoxLayout(padding=dp(10))
        self.board_widget = ChessBoardWidget(size_hint=(1, 1))
        self.board_widget.on_square_tapped = self._on_square_tapped
        board_container.add_widget(self.board_widget)
        root.add_widget(board_container)

        # --- Move history (horizontal-scrolling label for simplicity) ---
        history_scroll = MDScrollView(size_hint_y=None, height=dp(60))
        self.history_label = MDLabel(text="", halign="left", size_hint_y=None,
                                      theme_text_color="Custom", text_color=(0.75, 0.75, 0.8, 1))
        self.history_label.bind(texture_size=self._update_history_height)
        history_scroll.add_widget(self.history_label)
        root.add_widget(history_scroll)

        # --- Controls ---
        controls = MDBoxLayout(size_hint_y=None, height=dp(56), spacing=dp(8), padding=dp(8))
        for label, cb in [("Undo", self._on_undo), ("Restart", self._on_restart),
                           ("Resign", self._on_resign), ("Menu", self._on_menu)]:
            btn = MDFlatButton(text=label)
            btn.bind(on_release=lambda *_a, c=cb: c())
            controls.add_widget(btn)
        root.add_widget(controls)

        self.add_widget(root)

        # Board-tap selection state
        self.selected_square = None

    # ------------------------------------------------------------------
    def _update_history_height(self, *args):
        self.history_label.height = self.history_label.texture_size[1]

    # ------------------------------------------------------------------
    def start_new_game(self, mode="pvp", human_is_white=True, ai_difficulty="medium"):
        if self.move_manager is not None:
            self.move_manager.close()
        self._pending_promotion = None
        self.move_manager = MoveManager(mode=mode, human_is_white=human_is_white,
                                         ai_difficulty=ai_difficulty)
        self.move_manager.on_ai_move_start = self._on_ai_thinking_start
        self.move_manager.on_ai_move_end = self._on_ai_thinking_end
        self.move_manager.on_game_over = self._on_game_over
        self.board_widget.flipped = (mode == "pva" and not human_is_white)
        self.selected_square = None
        self._refresh_board()
        # If the human chose Black, the AI must play White's first
        # move now -- otherwise the game would silently sit waiting
        # for a human turn that isn't coming.
        self.move_manager.maybe_start_ai_turn()

    # ------------------------------------------------------------------
    def _on_square_tapped(self, square):
        if self.move_manager is None or self.move_manager.ai_thinking:
            return
        if not self.move_manager.is_human_turn():
            return
        if self.move_manager.is_game_over():
            return

        bm = self.move_manager.board_manager

        if self.selected_square is None:
            # First tap: select a piece if it belongs to the side to move.
            piece_map = bm.piece_map()
            if square in piece_map:
                _, is_white = piece_map[square]
                if is_white == bm.turn_is_white():
                    self.selected_square = square
                    self._refresh_board()
            return

        if square == self.selected_square:
            self.selected_square = None
            self._refresh_board()
            return

        # Second tap: promotion needs a piece choice before the move is pushed.
        if bm.is_promotion(self.selected_square, square):
            self._pending_promotion = (self.selected_square, square)
            self._show_promotion_dialog()
            return

        moved = self.move_manager.attempt_human_move(self.selected_square, square)
        self.selected_square = None
        if not moved:
            # Maybe they tapped a different one of their own pieces instead.
            piece_map = bm.piece_map()
            if square in piece_map and piece_map[square][1] == bm.turn_is_white():
                self.selected_square = square
        self._refresh_board()

    # ------------------------------------------------------------------
    def _show_promotion_dialog(self):
        options = MDBoxLayout(orientation="vertical", spacing=dp(6),
                              size_hint_y=None, height=dp(210), padding=dp(8))
        for label, code in [("Queen", "q"), ("Rook", "r"), ("Bishop", "b"), ("Knight", "n")]:
            btn = MDRaisedButton(text=label, size_hint_y=None, height=dp(44))
            btn.bind(on_release=lambda *_a, c=code: self._complete_promotion(c))
            options.add_widget(btn)
        self.dialog = MDDialog(title="Choose promotion", type="custom",
                               content_cls=options)
        self.dialog.open()

    def _complete_promotion(self, promotion):
        if self.dialog:
            self.dialog.dismiss()
        pending = self._pending_promotion
        self._pending_promotion = None
        if not pending or self.move_manager is None:
            return
        from_sq, to_sq = pending
        moved = self.move_manager.attempt_human_move(from_sq, to_sq, promotion)
        self.selected_square = None
        if not moved:
            self.selected_square = from_sq
        self._refresh_board()

    def _refresh_board(self):
        bm = self.move_manager.board_manager
        legal_targets = []
        if self.selected_square:
            legal_targets = [self._move_to_square_name(m) for m in
                              bm.legal_moves_from(self.selected_square)]

        self.board_widget.set_board_state(
            piece_positions=bm.piece_map(),
            selected_square=self.selected_square,
            legal_targets=legal_targets,
            last_move=bm.last_move_squares(),
            check_square=bm.king_square_in_check(),
        )

        turn_text = "White" if bm.turn_is_white() else "Black"
        status = f"{turn_text} to move"
        if bm.is_check():
            status += "  •  CHECK"
        self.status_label.text = status

        self.captured_label.text = self._captured_text(bm)
        self.history_label.text = self._history_text(bm)

    def _move_to_square_name(self, move):
        import chess
        return chess.square_name(move.to_square)

    def _captured_text(self, bm):
        w = " ".join(bm.captured_white) or "-"
        b = " ".join(bm.captured_black) or "-"
        return f"White captured: {w}    Black captured: {b}"

    def _history_text(self, bm):
        pairs = []
        moves = bm.san_history
        for i in range(0, len(moves), 2):
            num = i // 2 + 1
            white_move = moves[i]
            black_move = moves[i + 1] if i + 1 < len(moves) else ""
            pairs.append(f"{num}. {white_move} {black_move}")
        return "   ".join(pairs)

    # ------------------------------------------------------------------
    def _on_ai_thinking_start(self):
        self.status_label.text = "AI is thinking..."

    def _on_ai_thinking_end(self, move):
        self._refresh_board()

    def _on_game_over(self, result_text):
        self._show_dialog("Game Over", result_text)

    # ------------------------------------------------------------------
    def _on_undo(self):
        if self.move_manager and self.move_manager.undo():
            self.selected_square = None
            self._refresh_board()

    def _on_restart(self):
        if self.move_manager:
            self.move_manager.restart()
            self.selected_square = None
            self._refresh_board()

    def _on_resign(self):
        if self.move_manager:
            self.move_manager.resign()

    def _on_menu(self):
        self.manager.current = "home"

    def _show_dialog(self, title, text):
        if self.dialog:
            self.dialog.dismiss()
        self.dialog = MDDialog(title=title, text=text,
                                buttons=[MDFlatButton(text="OK",
                                         on_release=lambda *_: self.dialog.dismiss())])
        self.dialog.open()
