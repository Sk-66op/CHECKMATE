"""
home_screen.py
---------------
The app's landing screen. Built with KivyMD widgets for a polished,
Material-Design mobile look rather than plain Kivy buttons.
"""

from kivy.uix.screenmanager import Screen
from kivy.metrics import dp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.label import MDLabel
from kivymd.uix.dialog import MDDialog


class HomeScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._pva_dialog = None
        self._pva_color = "white"
        self._pva_difficulty = "medium"

        root = MDBoxLayout(orientation="vertical", padding=dp(30), spacing=dp(18),
                            md_bg_color=(0.11, 0.13, 0.16, 1))

        title = MDLabel(text="Chess AI", halign="center", font_style="H3",
                         theme_text_color="Custom", text_color=(0.93, 0.86, 0.72, 1),
                         size_hint_y=None, height=dp(90))
        subtitle = MDLabel(text="CHECKMATE", halign="center", font_style="Subtitle1",
                            theme_text_color="Custom", text_color=(0.6, 0.6, 0.65, 1),
                            size_hint_y=None, height=dp(30))

        root.add_widget(title)
        root.add_widget(subtitle)

        root.add_widget(self._menu_button("Play vs AI", self._go_pva))
        root.add_widget(self._menu_button("Play vs Player", self._go_pvp))
        root.add_widget(self._menu_button("Settings", self._go_settings))
        root.add_widget(self._menu_button("About", self._go_about))

        exit_btn = MDFlatButton(text="Exit", pos_hint={"center_x": 0.5},
                                 theme_text_color="Custom", text_color=(0.8, 0.3, 0.3, 1))
        exit_btn.bind(on_release=lambda *_: self._exit_app())
        root.add_widget(exit_btn)

        self.add_widget(root)

    def _menu_button(self, text, callback):
        btn = MDRaisedButton(text=text, size_hint=(1, None), height=dp(54),
                              md_bg_color=(0.2, 0.45, 0.35, 1))
        btn.bind(on_release=lambda *_: callback())
        return btn

    def _go_pva(self):
        """Show a quick color + difficulty picker before starting a
        Player vs AI game."""
        content = MDBoxLayout(orientation="vertical", spacing=dp(10),
                               size_hint_y=None, height=dp(160), padding=dp(10))

        color_row = MDBoxLayout(spacing=dp(8), size_hint_y=None, height=dp(48))
        for label, value in [("Play White", "white"), ("Play Black", "black")]:
            b = MDFlatButton(text=label)
            b.bind(on_release=lambda *_a, v=value: self._set_pva_color(v))
            color_row.add_widget(b)
        content.add_widget(color_row)

        diff_row = MDBoxLayout(spacing=dp(8), size_hint_y=None, height=dp(48))
        for label, value in [("Easy", "easy"), ("Medium", "medium"), ("Hard", "hard")]:
            b = MDFlatButton(text=label)
            b.bind(on_release=lambda *_a, v=value: self._set_pva_difficulty(v))
            diff_row.add_widget(b)
        content.add_widget(diff_row)

        self._pva_dialog = MDDialog(
            title="Play vs AI",
            type="custom",
            content_cls=content,
            buttons=[MDRaisedButton(text="Start Game", on_release=lambda *_: self._start_pva())],
        )
        self._pva_dialog.open()

    def _set_pva_color(self, value):
        self._pva_color = value

    def _set_pva_difficulty(self, value):
        self._pva_difficulty = value

    def _start_pva(self):
        if self._pva_dialog:
            self._pva_dialog.dismiss()
        game_screen = self.manager.get_screen("game")
        game_screen.start_new_game(mode="pva",
                                    human_is_white=(self._pva_color == "white"),
                                    ai_difficulty=self._pva_difficulty)
        self.manager.current = "game"

    def _go_pvp(self):
        game_screen = self.manager.get_screen("game")
        game_screen.start_new_game(mode="pvp")
        self.manager.current = "game"

    def _go_settings(self):
        self.manager.current = "settings"

    def _go_about(self):
        self.manager.current = "about"

    def _exit_app(self):
        from kivy.app import App
        App.get_running_app().stop()
