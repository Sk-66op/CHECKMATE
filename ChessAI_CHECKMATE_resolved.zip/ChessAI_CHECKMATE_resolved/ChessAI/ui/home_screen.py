"""
home_screen.py
---------------
The app's landing screen. Built with KivyMD widgets for a polished,
Material-Design mobile look rather than plain Kivy buttons.
"""

from kivy.metrics import dp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.label import MDLabel
from kivymd.uix.card import MDCard
from kivy.uix.image import Image
from kivy.graphics import Color, RoundedRectangle

class HomeScreen(MDBoxLayout):
    def __init__(self, switch_screen_callback, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = dp(24)
        self.spacing = dp(20)
        self.switch_screen = switch_screen_callback

        # Set background color explicitly to deep charcoal (#121212)
        with self.canvas.before:
            Color(0.07, 0.07, 0.07, 1)  # #121212
            self.bg_rect = RoundedRectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_bg, pos=self._update_bg)

        # Top spacing / Header container
        self.add_widget(MDBoxLayout(size_hint_y=0.15))

        # Title & Subtitle Section
        title_layout = MDBoxLayout(orientation='vertical', size_hint_y=0.2, spacing=dp(5))
        
        self.title_label = MDLabel(
            text="CHESS AI",
            halign="center",
            font_style="H4",
            bold=True,
            theme_text_color="Custom",
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        self.subtitle_label = MDLabel(
            text="THINK • PLAY • CONQUER",
            halign="center",
            font_style="Caption",
            theme_text_color="Custom",
            text_color=(0.6, 0.6, 0.6, 1)
        )
        
        title_layout.add_widget(self.title_label)
        title_layout.add_widget(self.subtitle_label)
        self.add_widget(title_layout)

        # Center Navigation Card Container
        nav_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15),
            size_hint=(0.85, None),
            height=dp(240),
            pos_hint={'center_x': 0.5},
            elevation=2,
            md_bg_color=(0.12, 0.12, 0.12, 1) # Slightly lighter dark surface (#1E1E1E equivalent)
        )

        # Primary Buttons styled as modern selection cards
        btn_vs_ai = MDRaisedButton(
            text="PLAY VS AI",
            size_hint=(1, None),
            height=dp(50),
            md_bg_color=(0, 0.9, 1, 1),  # Electric Cyan Accent
            text_color=(0.07, 0.07, 0.07, 1),
            elevation=0,
            on_release=lambda x: self.switch_screen('mode_select') # Or 'game' depending on flow
        )
        btn_vs_ai.font_size = '16sp'
        btn_vs_ai.bold = True

        btn_vs_player = MDRaisedButton(
            text="PLAY WITH FRIEND",
            size_hint=(1, None),
            height=dp(50),
            md_bg_color=(0.18, 0.18, 0.18, 1),
            text_color=(0.9, 0.9, 0.9, 1),
            elevation=0,
            on_release=lambda x: self.switch_screen('game_pvp')
        )
        btn_vs_player.font_size = '16sp'

        btn_settings = MDRaisedButton(
            text="SETTINGS",
            size_hint=(1, None),
            height=dp(50),
            md_bg_color=(0.18, 0.18, 0.18, 1),
            text_color=(0.9, 0.9, 0.9, 1),
            elevation=0,
            on_release=lambda x: self.switch_screen('settings')
        )
        btn_settings.font_size = '16sp'

        nav_card.add_widget(btn_vs_ai)
        nav_card.add_widget(btn_vs_player)
        nav_card.add_widget(btn_settings)
        
        self.add_widget(nav_card)

        # Bottom Space & Footer Info
        self.add_widget(MDBoxLayout(size_hint_y=0.15))

        footer_layout = MDBoxLayout(size_hint_y=0.1, padding=dp(10))
        self.about_btn = MDFlatButton(
            text="About • Version 1.0.0",
            halign="center",
            pos_hint={'center_x': 0.5},
            theme_text_color="Custom",
            text_color=(0.5, 0.5, 0.5, 1),
            on_release=lambda x: self.switch_screen('about')
        )
        footer_layout.add_widget(self.about_btn)
        self.add_widget(footer_layout)

    def _update_bg(self, instance, value):
        self.bg_rect.pos = instance.pos
        self.bg_rect.size = instance.size

