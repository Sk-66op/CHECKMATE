"""
settings_screen.py
-------------------
Lets the user configure default AI difficulty, default color,
sound, legal-move highlighting, and theme. Persisted to
data/settings.json under the app's Android-safe user_data_dir.
"""

import json
import os
from kivy.uix.screenmanager import Screen
from kivy.metrics import dp
from kivy.app import App
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.label import MDLabel
from kivymd.uix.selectioncontrol import MDSwitch

DEFAULT_SETTINGS = {
    "ai_difficulty": "medium",
    "default_color": "white",
    "sound_on": True,
    "highlight_legal_moves": True,
    "theme": "classic",
}


def settings_path():
    app = App.get_running_app()
    base = app.user_data_dir if app else "."
    return os.path.join(base, "settings.json")


def load_settings():
    path = settings_path()
    if os.path.exists(path):
        try:
            with open(path, "r") as f:
                data = json.load(f)
            merged = dict(DEFAULT_SETTINGS)
            merged.update(data)
            return merged
        except (json.JSONDecodeError, OSError):
            pass
    return dict(DEFAULT_SETTINGS)


def save_settings(settings: dict):
    path = settings_path()
    try:
        with open(path, "w") as f:
            json.dump(settings, f, indent=2)
    except OSError:
        pass  # Non-fatal: app still works with in-memory settings this session.


class SettingsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.settings = load_settings()

        root = MDBoxLayout(orientation="vertical", padding=dp(24), spacing=dp(16),
                            md_bg_color=(0.11, 0.13, 0.16, 1))

        root.add_widget(MDLabel(text="Settings", font_style="H4", size_hint_y=None,
                                 height=dp(50), theme_text_color="Custom",
                                 text_color=(0.93, 0.86, 0.72, 1)))

        root.add_widget(self._section_label("AI Difficulty"))
        diff_row = MDBoxLayout(spacing=dp(8), size_hint_y=None, height=dp(48))
        for label, value in [("Easy", "easy"), ("Medium", "medium"), ("Hard", "hard")]:
            b = MDFlatButton(text=label)
            b.bind(on_release=lambda *_a, v=value: self._set("ai_difficulty", v))
            diff_row.add_widget(b)
        root.add_widget(diff_row)

        root.add_widget(self._section_label("Default Player Color"))
        color_row = MDBoxLayout(spacing=dp(8), size_hint_y=None, height=dp(48))
        for label, value in [("White", "white"), ("Black", "black")]:
            b = MDFlatButton(text=label)
            b.bind(on_release=lambda *_a, v=value: self._set("default_color", v))
            color_row.add_widget(b)
        root.add_widget(color_row)

        root.add_widget(self._switch_row("Sound", "sound_on"))
        root.add_widget(self._switch_row("Highlight Legal Moves", "highlight_legal_moves"))

        btn_row = MDBoxLayout(spacing=dp(12), size_hint_y=None, height=dp(50))
        reset_btn = MDFlatButton(text="Reset to Defaults")
        reset_btn.bind(on_release=lambda *_: self._reset())
        back_btn = MDRaisedButton(text="Back")
        back_btn.bind(on_release=lambda *_: self._go_back())
        btn_row.add_widget(reset_btn)
        btn_row.add_widget(back_btn)
        root.add_widget(btn_row)

        self.add_widget(root)

    def _section_label(self, text):
        return MDLabel(text=text, size_hint_y=None, height=dp(28),
                        theme_text_color="Custom", text_color=(0.75, 0.75, 0.8, 1))

    def _switch_row(self, label, key):
        row = MDBoxLayout(size_hint_y=None, height=dp(44))
        row.add_widget(MDLabel(text=label, theme_text_color="Custom",
                                text_color=(0.9, 0.9, 0.9, 1)))

        switch = MDSwitch()
        switch.active = self.settings.get(key, True)
        switch.bind(active=lambda inst, val: self._set(key, val))
        row.add_widget(switch)
        return row

    def _set(self, key, value):
        self.settings[key] = value
        save_settings(self.settings)

    def _reset(self):
        self.settings = dict(DEFAULT_SETTINGS)
        save_settings(self.settings)

    def _go_back(self):
        self.manager.current = "home"
