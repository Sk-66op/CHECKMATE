# Android Build Checklist

## Recommended environment
- Linux or WSL2
- Build from the Linux filesystem (for example `~/ChessAI`), not `/mnt/c/...`
- Java 17
- Buildozer 1.6.x or current stable

## Build

```bash
cd ~/ChessAI
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install buildozer cython==0.29.34
buildozer android debug
```

The first build downloads the Android toolchain and can take a long time.

## Output

The APK is written under `bin/`. Copy it to the Windows filesystem if using WSL2 and install it with ADB from Windows.

## If the build fails

Run:

```bash
buildozer -v android debug 2>&1 | tee build.log
```

Keep the **first meaningful error** and the surrounding 30-50 lines. Do not change dependency versions blindly before checking the error.
