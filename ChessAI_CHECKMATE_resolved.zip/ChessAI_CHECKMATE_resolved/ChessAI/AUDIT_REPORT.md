# AUDIT_REPORT.md — Dependency, Compatibility & Build-Process Audit

**Scope:** dependency versions, Kivy/KivyMD compatibility, python-chess
integration, `buildozer.spec`, asset paths, Android permissions, and the
actual build/test commands. No new features added.

## Environment constraint (same as TEST_REPORT.md)

This sandbox still has no network access, so none of this could be
verified by actually running `buildozer android debug` here. What follows
is a **static audit** (reading the actual project files) combined with
**current, dated information pulled from the web** about buildozer/Kivy/
KivyMD/Android tooling as of 2025–2026, so the version pins reflect
present-day reality rather than my training data. Where I found solid,
recent sourcing I say so; where I did not, I say that too. **You still
need to run the commands at the end on your own machine and tell me what
actually happens** — that's the only way this gets from "audited" to
"verified."

## 1. Dependency versions — `requirements.txt` / `buildozer.spec`

| Package | Pinned | Audit finding |
|---|---|---|
| `chess` (python-chess) | 1.10.0 | Pip package name confirmed correct (`chess`, not `python-chess`). Pure Python, no native build step — lowest-risk dependency in the stack. |
| `kivy` | 2.3.0 | Current stable Kivy (2.3.1 is the latest point release) officially supports Python 3.8–3.13, so it's compatible with the project's Python 3 target. |
| `kivymd` | 1.2.0 | **Could not independently confirm this exact version builds cleanly against `kivy==2.3.0` via Buildozer.** Every KivyMD release-note pairing I could find explicitly documents a specific Kivy version alongside it — e.g. KivyMD 1.0.1's own docs specify `kivy==2.1.0` alongside it, and KivyMD 2.0.0 explicitly requires `Kivy >= 2.3.0`. 1.2.0 sits in between those two documented pairings and I found no explicit statement of what it expects. This is a real, un-eliminated risk, not a solved one. |
| `pillow` | latest (buildozer.spec only — missing from `requirements.txt`) | KivyMD's documented Buildozer recipes consistently include `pillow` alongside `kivy`/`kivymd`. It was already in `buildozer.spec` but **not in `requirements.txt`**, so a plain `pip install -r requirements.txt` desktop setup could behave slightly differently from the packaged app. **Fixed** — added to `requirements.txt` (see below). |

**A specific historical risk worth knowing about:** a Buildozer GitHub
issue reported compilation failures with Buildozer when using Kivy versions above 2.1.0, or Kivy's master branch, as a requirement. That report is from November 2023 and centers on the `kivy==master` development branch rather than a pinned stable release, so it may not apply to `kivy==2.3.0` specifically — but I could not find a clear "yes, 2.3.0 stable definitely builds fine via Buildozer" confirmation either. **This is the single biggest unresolved risk in the whole stack.**

**Fallback if the current pin fails to build:** the most consistently documented, actually-paired-together combination across multiple KivyMD release docs is kivy==2.1.0, kivymd==1.0.1, sdl2_ttf==2.0.15, and pillow (same shape holds for kivymd 1.1.1). I've added this as a commented fallback directly in `buildozer.spec` so you don't have to hunt for it if the first build fails. The `sdl2_ttf` pin specifically exists because newer default SDL2_ttf builds have caused crashes on some devices in community reports — worth keeping even on the fallback path.

**Fix made:** added `pillow` to `requirements.txt` so desktop and Android dependency sets match.

## 2. python-chess integration

Reviewed `board_manager.py`, `search.py`, `evaluation.py`, `ai_engine.py`,
`move_manager.py` again specifically for anything that would only work on
desktop Python and not under python-for-android:

- No use of `multiprocessing`, `ctypes`, or any C-extension-dependent
  chess library — `python-chess` is pure Python, so it doesn't need a
  p4a "recipe" and should install into the APK exactly like any other
  pure-Python dependency listed in `requirements =`.
- No filesystem access, no OS-specific path handling, no desktop-only
  imports anywhere in `chess_engine/`.
- Threading use (`threading.Thread` + `kivy.clock.Clock.schedule_once`
  in `move_manager.py`) is the standard, documented cross-platform Kivy
  pattern for background work and is not Android-risky in itself — but
  see the Buildozer/Gradle build note below, which is a *build-time*
  Java-toolchain risk, unrelated to this app's own Python threading.

**Finding:** no integration bugs found here beyond what TEST_REPORT.md
already covers (undo/AI-first-move fixes). Nothing new to fix in this
audit.

## 3. Asset paths

- `assets/pieces/`, `assets/sounds/`, `assets/themes/` currently contain
  only placeholder `.gitkeep` files — the app draws pieces with Unicode
  glyphs at runtime and loads no image/sound assets, so there is nothing
  that can go missing at build time. Confirmed by `grep` — no `Image()`,
  `SoundLoader`, or asset-path string anywhere in `ui/` or
  `chess_engine/`.
- `buildozer.spec`'s `source.include_exts` already covers every extension
  used in the repo (`py`) plus the extensions you'd need if you add real
  assets later (`png,jpg,jpeg,kv,atlas,json,ttf,wav,ogg,mp3`). No change
  needed — this was already correctly forward-looking.
- The only runtime-written file, `settings.json`, is written to
  `App.get_running_app().user_data_dir` (`settings_screen.py`), which is
  the correct Android-safe, permission-free private-storage location —
  confirmed unchanged from the previous review.

**Finding:** no asset-path issues.

## 4. Android permissions

**Bug found and fixed:** `android.permissions = INTERNET` was set with
**no corresponding feature in the code that uses the network** — the app
makes zero network calls (confirmed by the same `grep` used in the
previous review pass). Requesting an unused permission is bad practice
(unnecessary user-facing permission prompt, unnecessary attack surface,
and it's the kind of thing a viva examiner or Play Store reviewer would
reasonably ask you to justify). **Fixed:** cleared
`android.permissions =` in `buildozer.spec`. If you add a feature that
genuinely needs it later (e.g. online multiplayer), add the specific
permission back then.

## 5. `buildozer.spec` — remaining configuration audit

- **`android.api = 33`** — fine for installing/running a debug APK on
  your own device via `adb install`; this is not blocked by Play Store
  policy since you're not submitting to the Store. Worth knowing for the
  future though: Google Play requires new apps and updates to target API level 35 (Android 15) as of August 31, 2025, and API level 36 (Android 16) starting August 31, 2026 — so if this project is ever submitted to the Play Store rather than just sideloaded for a viva demo, `android.api` will need bumping past 33 first. Left at 33 for now since it's not required for local testing and bumping it pulls in newer SDK platform/build-tools that add their own risk to an already-uncertain first build.
- **`android.ndk = 25b`** — this is p4a's own currently-recommended NDK version per a community verification note, and current Buildozer documentation (dated mid-2026) separately confirms NDK 28c also works if you need an alternative. Left at 25b; documented 28c as the fallback directly in the spec file comment.
- **`android.enable_androidx = True`** — correct/required for any modern KivyMD build; unchanged.
- Nothing else in the spec references files that don't exist (double-checked `icon.filename` is commented out, matching that no `assets/icon.png` exists yet).

## 6. Build-toolchain / WSL2-specific findings (new — not covered in TEST_REPORT.md)

Pulled from current Buildozer documentation and a Buildozer/python-for-android GitHub issue thread:

- **WSL1 is explicitly unsupported now** — legacy WSL1 users must upgrade to WSL2, since WSL1 has a known fatal issue. If you're on WSL1, upgrade first (`wsl --set-version <distro> 2` from PowerShell, or `wsl --install` fresh).
- **Build on the Linux filesystem, not `/mnt/c`** — the official guidance is to copy the project into the WSL filesystem (under home) rather than building from the Windows-mounted partition, both for a roughly 5x speed difference and because an NTFS-mounted drive on Linux can cause some Python packages to misbehave as if configured for Windows.
- **JDK version matters and has a known conflict**: if openjdk-17 conflicts with other installed programs, the minimum Buildozer-compatible openjdk version is 11 — but separately, a currently-open python-for-android issue reports that Gradle 8.x (which current python-for-android uses) requires JDK 17, while attempting JDK 17 on WSL1 hits a separate known failure, and switching from JDK 11 to 17 has produced "Cannot allocate memory" errors during the mergeReleaseJniLibFolders Gradle task on some setups. Net effect: **use JDK 17 on WSL2** (not WSL1) as the primary path; if you hit an out-of-memory-style Gradle failure, that's a known symptom, not a project bug — see the WSL2 memory note below.
- **WSL2 memory limits are a common, unrelated cause of build failures.** WSL2 defaults to using up to 50% of host RAM for its VM, which can be too little for a Gradle+NDK build on a machine with 8–16GB total RAM. If the build fails deep in a native-compile or Gradle step with an out-of-memory-shaped error, increase the WSL2 memory limit via a `.wslconfig` file (see command list below) before assuming it's a project/code problem.
- **No direct USB access from WSL2** — for on-device testing, copy the built .apk to the Windows filesystem and run ADB from a Windows prompt rather than trying to reach a USB-connected phone from inside WSL2 directly.

None of this is specific to this project's code — it's generic Buildozer/WSL2 environment setup — but it directly affects whether your first build attempt succeeds, so it belongs in this audit rather than being left for you to discover via a cryptic build failure.

## Summary of changes made this pass

1. `buildozer.spec`: removed the unused `INTERNET` permission.
2. `buildozer.spec`: added a documented fallback dependency pin (`kivy==2.1.0, kivymd==1.1.1, sdl2_ttf==2.0.15`) as a comment, for use if the current `kivy==2.3.0`/`kivymd==1.2.0` pin fails to build.
3. `buildozer.spec`: documented NDK 28c as a fallback if 25b fails.
4. `requirements.txt`: added `pillow` so desktop and Android dependency sets match.
5. No source code changes in this pass — this was a dependency/config audit only, per your instruction not to add features.

## What is still genuinely unverified

- Whether `kivy==2.3.0` + `kivymd==1.2.0` actually compiles together via Buildozer at all — **this is the top risk in the project right now** and can only be resolved by attempting the build.
- Whether the app runs correctly on a real device/emulator once built (touch input, KivyMD dialog rendering, board scaling on a small screen).
- Everything already flagged as unverified in `TEST_REPORT.md` (chess-rule execution, undo edge case after an AI-only opening move).
